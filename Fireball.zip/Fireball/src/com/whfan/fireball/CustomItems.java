package com.whfan.fireball;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.util.Vector;

public class CustomItems
  implements Listener
{
  private static Main main;
  
  public CustomItems(Main main)
  {
    main = main;
  }
  
  @EventHandler
  public void flameThrower(PlayerInteractEvent e)
  {
    final Player player = e.getPlayer();
    if (((e.getAction() == Action.RIGHT_CLICK_AIR) || (e.getAction() == Action.RIGHT_CLICK_BLOCK)) && 
      (player.getInventory().getItemInMainHand().getType().equals(Material.BLAZE_ROD)) && (player.getInventory().getItemInMainHand().getItemMeta().getDisplayName().equals(ChatColor.RED + "Flamethrower")))
    {
      FallingBlock block1 = e.getPlayer().getWorld().spawnFallingBlock(e.getPlayer().getLocation(), Material.FIRE, (byte)0);
      FallingBlock block2 = e.getPlayer().getWorld().spawnFallingBlock(e.getPlayer().getLocation(), Material.FIRE, (byte)0);
      FallingBlock block3 = e.getPlayer().getWorld().spawnFallingBlock(e.getPlayer().getLocation(), Material.FIRE, (byte)0);
      
      double pitch1 = (player.getLocation().getPitch() + 50.0F) * 3.141592653589793D / 180.0D;
      double yaw1 = (player.getLocation().getYaw() + 80.0F) * 3.141592653589793D / 180.0D;
      
      double x1 = Math.sin(pitch1) * Math.cos(yaw1);
      double y1 = Math.sin(pitch1) * Math.sin(yaw1);
      double z1 = Math.cos(pitch1);
      
      Vector vector1 = new Vector(x1 / 1.5D, z1 / 1.5D, y1 / 1.5D);
      
      double pitch2 = (player.getLocation().getPitch() + 50.0F) * 3.141592653589793D / 180.0D;
      double yaw2 = (player.getLocation().getYaw() + 90.0F) * 3.141592653589793D / 180.0D;
      
      double x2 = Math.sin(pitch2) * Math.cos(yaw2);
      double y2 = Math.sin(pitch2) * Math.sin(yaw2);
      double z2 = Math.cos(pitch2);
      
      Vector vector2 = new Vector(x2 / 1.4D, z2 / 1.4D, y2 / 1.4D);
      
      double pitch3 = (player.getLocation().getPitch() + 50.0F) * 3.141592653589793D / 180.0D;
      double yaw3 = (player.getLocation().getYaw() + 100.0F) * 3.141592653589793D / 180.0D;
      
      double x3 = Math.sin(pitch3) * Math.cos(yaw3);
      double y3 = Math.sin(pitch3) * Math.sin(yaw3);
      double z3 = Math.cos(pitch3);
      
      Vector vector3 = new Vector(x3 / 1.5D, z3 / 1.5D, y3 / 1.5D);
      
      main.immuneToFire.add(player);
      
      block1.setVelocity(vector1);
      block2.setVelocity(vector2);
      block3.setVelocity(vector3);
      
      Bukkit.getScheduler().runTaskLater(main, new Runnable()
      {
        public void run()
        {
          Main.fire.add(block1);
          Main.fire.add(block2);
          Main.fire.add(block3);
        }
      }, 10L);
    }
  }
  
  @EventHandler
  public void immuneToFire(EntityDamageEvent e)
  {
    Entity entity = e.getEntity();
    if (((entity instanceof Player)) && 
      ((e.getCause() == EntityDamageEvent.DamageCause.FIRE) || (e.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK)) && 
      (main.immuneToFire.contains(entity))) {
      e.setCancelled(true);
    }
  }
}
