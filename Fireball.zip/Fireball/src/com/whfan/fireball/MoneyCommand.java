package com.whfan.fireball;

import java.util.HashMap;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MoneyCommand
  implements CommandExecutor
{
  private Main main;
  
  public MoneyCommand(Main main)
  {
    this.main = main;
  }
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player player = (Player)sender;
    if (args.length != 0)
    {
      if (Bukkit.getPlayer(args[0].toString()) == null) {
        player.sendMessage("That player is offline.");
      } else {
        player.sendMessage(args[0].toString() + " has " + (String)this.main.money.get(Bukkit.getPlayer(args[0].toString()).getUniqueId()) + " coins.");
      }
    }
    else {
      player.sendMessage("You have " + (String)this.main.money.get(player.getUniqueId()) + " coins.");
    }
    return false;
  }
}
