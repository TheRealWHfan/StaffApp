package com.whfan.fireball;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ShopCommand
  implements CommandExecutor
{
  private Main main;
  
  public ShopCommand(Main main)
  {
    this.main = main;
  }
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player player = (Player)sender;
    
    Inventory shop = Bukkit.createInventory(null, 27, ChatColor.GOLD + "" + ChatColor.BOLD + "Shop");
    ItemStack glassPane = new ItemStack(Material.STAINED_GLASS_PANE);
    ItemMeta glassPaneMeta = glassPane.getItemMeta();
    glassPaneMeta.setDisplayName(" ");
    glassPane.setItemMeta(glassPaneMeta);
    
    ItemStack glassPanePink = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)6);
    ItemMeta glassPanePinkMeta = glassPanePink.getItemMeta();
    glassPanePinkMeta.setDisplayName(" ");
    glassPanePink.setItemMeta(glassPanePinkMeta);
    
    ItemStack explosiveEgg = new ItemStack(Material.EGG, 1);
    ItemMeta explosiveEggMeta = explosiveEgg.getItemMeta();
    explosiveEggMeta.setDisplayName(ChatColor.YELLOW + "Explosive Egg");
    explosiveEgg.setItemMeta(explosiveEggMeta);
    
    ItemStack flameThrower = new ItemStack(Material.BLAZE_ROD, 1);
    ItemMeta flameThrowerMeta = flameThrower.getItemMeta();
    flameThrowerMeta.setDisplayName(ChatColor.RED + "Flamethrower");
    flameThrowerMeta.addEnchant(Enchantment.FIRE_ASPECT, 1, true);
    flameThrower.setItemMeta(flameThrowerMeta);
    
    ItemStack baseRepair = new ItemStack(Material.IRON_PICKAXE, 1);
    ItemMeta baseRepairMeta = baseRepair.getItemMeta();
    baseRepairMeta.setDisplayName(ChatColor.GREEN + "Base Repair");
    baseRepairMeta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, true);
    baseRepair.setItemMeta(baseRepairMeta);
    
    shop.setItem(0, glassPanePink);
    shop.setItem(1, glassPane);
    shop.setItem(2, glassPane);
    shop.setItem(3, glassPane);
    shop.setItem(4, glassPane);
    shop.setItem(5, glassPane);
    shop.setItem(6, glassPane);
    shop.setItem(7, glassPane);
    shop.setItem(8, glassPanePink);
    shop.setItem(9, glassPane);
    shop.setItem(12, flameThrower);
    shop.setItem(13, explosiveEgg);
    shop.setItem(14, baseRepair);
    shop.setItem(17, glassPane);
    shop.setItem(18, glassPanePink);
    shop.setItem(19, glassPane);
    shop.setItem(20, glassPane);
    shop.setItem(21, glassPane);
    shop.setItem(22, glassPane);
    shop.setItem(23, glassPane);
    shop.setItem(24, glassPane);
    shop.setItem(25, glassPane);
    shop.setItem(26, glassPanePink);
    if (player.isOp()) {
      player.openInventory(shop);
    } else {
      player.sendMessage("No just no.");
    }
    return false;
  }
}
