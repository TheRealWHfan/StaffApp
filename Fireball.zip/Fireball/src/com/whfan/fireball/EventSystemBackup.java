package com.whfan.fireball;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.schematic.MCEditSchematicFormat;

public class EventSystemBackup implements Listener {

	private static Main main;

	public EventSystemBackup(Main main) {
		EventSystemBackup.main = main;
	}

	public static void InfiltrationWin() {
		//Loop Over all Players From Both Teams
		for (Player blueTeamPlayer : Bukkit.getOnlinePlayers()) {
			for (Player redTeamPlayer : Bukkit.getOnlinePlayers()) {
				//Check to see if Blue team has a Red banner
				if (blueTeamPlayer.getInventory().contains(Material.BANNER, (short) 4)) {
					//Set the mode back to default
					StartCommand.mode = ModeEnum.NoMode;
					//Message a Red player that Blue won
					redTeamPlayer.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Blue", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
					//Reset the team size
					StartCommand.teamSize = "0";
					//Setup The reset Task
					Bukkit.getScheduler().runTaskLater(main, new Runnable() {
						public void run() {
							StartCommand.Blue.clear();
							StartCommand.Red.clear();
							redTeamPlayer.setGameMode(GameMode.ADVENTURE);
							redTeamPlayer.getInventory().clear();
							if (StartCommand.map == MapEnum.AirBase) {
								Main.Messaged.clear();
								WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
								File ABSchematic1 = new File("plugins/WorldEdit/schematics/ABSchematic1.schematic");
								File ABSchematic2 = new File("plugins/WorldEdit/schematics/ABSchematic2.schematic");
								EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(Bukkit.getServer().getWorld("Fire")), 1000000);
								try {
									MCEditSchematicFormat.getFormat(ABSchematic1).load(ABSchematic1).paste(session, new Vector(-62,76,0), false);
								} catch (MaxChangedBlocksException
										| com.sk89q.worldedit.data.DataException | IOException e2) {
									e2.printStackTrace();
								}
								Bukkit.getScheduler().runTaskLater(main, new Runnable() {
									public void run() {
										try {
											MCEditSchematicFormat.getFormat(ABSchematic2).load(ABSchematic2).paste(session, new Vector(-62,76,0), false);
											StartCommand.teamSize = new String("NoGame");
											StartCommand.mode = new String("NoMode");
											StartCommand.map = new String("NoMap");
											redTeamPlayer.teleport(new Location(Bukkit.getServer().getWorld("world"), -207, 64, 222));
											redTeamPlayer.setGameMode(GameMode.SURVIVAL);
										} catch (MaxChangedBlocksException
												| com.sk89q.worldedit.data.DataException | IOException e2) {
											e2.printStackTrace();
										}
									}
								}, 60L);
							}
						}
					}, 100L);
				} else {
					if (blueTeamPlayer.getInventory().contains(Material.BANNER, (short) 1)) { //Red
						StartCommand.mode = new String("NoMode");
						redTeamPlayer.sendTitle(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Blue", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
						StartCommand.teamSize = new String("NotReady");
						Bukkit.getScheduler().runTaskLater(main, new Runnable() {
							public void run() {
								StartCommand.Blue.clear();
								StartCommand.Red.clear();
								redTeamPlayer.setGameMode(GameMode.SURVIVAL);
								redTeamPlayer.teleport(new Location(Bukkit.getServer().getWorld("world"), -207, 64, 222));
								redTeamPlayer.getInventory().clear();
								Bukkit.getScheduler().runTaskLater(main, new Runnable() {
									public void run() {
										StartCommand.Blue.clear();
										StartCommand.Red.clear();
										redTeamPlayer.setGameMode(GameMode.SURVIVAL);
										redTeamPlayer.teleport(new Location(Bukkit.getServer().getWorld("world"), -207, 64, 222));
										redTeamPlayer.getInventory().clear();
										if (StartCommand.map.equals("AB")) {
											Main.Messaged.clear();
											WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
											File ABSchematic1 = new File("plugins/WorldEdit/schematics/ABSchematic1.schematic");
											File ABSchematic2 = new File("plugins/WorldEdit/schematics/ABSchematic2.schematic");
											EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(Bukkit.getServer().getWorld("Fire")), 1000000);
											try {
												MCEditSchematicFormat.getFormat(ABSchematic1).load(ABSchematic1).paste(session, new Vector(-62,76,0), false);
											} catch (MaxChangedBlocksException
													| com.sk89q.worldedit.data.DataException | IOException e2) {
												e2.printStackTrace();
											}
											Bukkit.getScheduler().runTaskLater(main, new Runnable() {
												public void run() {
													try {
														MCEditSchematicFormat.getFormat(ABSchematic2).load(ABSchematic2).paste(session, new Vector(-62,76,0), false);
														StartCommand.teamSize = new String("NoGame");
														StartCommand.mode = new String("NoMode");
														StartCommand.map = new String("NoMap");
														redTeamPlayer.teleport(new Location(Bukkit.getServer().getWorld("world"), -207, 64, 222));
														redTeamPlayer.setGameMode(GameMode.SURVIVAL);
													} catch (MaxChangedBlocksException
															| com.sk89q.worldedit.data.DataException | IOException e2) {
														e2.printStackTrace();
													}
												}
											}, 60L);
										}
									}
								}, 100L);
							}
						}, 100L);
					}
				}

			}
		}
	}

	@EventHandler
	public void onFakeDeath(EntityDamageEvent e) {

		Entity damaged = e.getEntity();

		if (!StartCommand.teamSize.equals("NoGame") || !StartCommand.teamSize.equals("NotReady")) { 
			if (damaged instanceof Player) {
				if (((Player) damaged).getHealth()-e.getDamage() <= 0) {
					e.setCancelled(true);
					World w = null;
					if(Bukkit.getServer().getWorld("Fire") == null){
						w = Bukkit.getServer().getWorld("world");
					} else {
						w = Bukkit.getServer().getWorld("Fire");
					}
					if (StartCommand.mode.equals("Classic")) {
						((Player) damaged).sendTitle(ChatColor.RED + "You have just died!", "", 20, 40, 20);
						((Player) damaged).setHealth(20);
						StartCommand.Spectator.add((Player) damaged);
						((Player) damaged).setGameMode(GameMode.SPECTATOR);
						damaged.teleport(new Location(w, 0, 76, 0));
						if (StartCommand.Blue.contains((Player) damaged)) {
							StartCommand.Blue.remove((Player) damaged);
							if (StartCommand.Blue.size() == 0) {
								for (Player aop : Bukkit.getOnlinePlayers()) {
									aop.setGameMode(GameMode.ADVENTURE);
									aop.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.GREEN + "has just won the game!", 20, 60, 20);
									StartCommand.teamSize = new String("NotReady");
									Bukkit.getScheduler().runTaskLater(main, new Runnable() {
										public void run() {
											World w = null;
											if(Bukkit.getServer().getWorld("Fire") == null){
												w = Bukkit.getServer().getWorld("world");
											} else {
												w = Bukkit.getServer().getWorld("Fire");
											}
											StartCommand.Blue.clear();
											StartCommand.Red.clear();
											aop.getInventory().clear();
											if (StartCommand.map.equals("SF")) {
												WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
												File SFSchematic1 = new File("plugins/WorldEdit/schematics/SFSchematic1.schematic");
												File SFSchematic2 = new File("plugins/WorldEdit/schematics/SFSchematic2.schematic");
												EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
												try {
													MCEditSchematicFormat.getFormat(SFSchematic1).load(SFSchematic1).paste(session, new Vector(0,76,0), false);
												} catch (MaxChangedBlocksException
														| com.sk89q.worldedit.data.DataException | IOException e2) {
													e2.printStackTrace();
												}
												Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
													public void run() {
														try {
															MCEditSchematicFormat.getFormat(SFSchematic2).load(SFSchematic2).paste(session, new Vector(0,76,0), false);
															StartCommand.teamSize = new String("NoGame");
															StartCommand.mode = new String("NoMode");
															StartCommand.map = new String("NoMap");
															aop.teleport((Bukkit.getServer().getWorld("world").getSpawnLocation()));
															aop.getInventory().clear();
															aop.setGameMode(GameMode.SURVIVAL);
														} catch (MaxChangedBlocksException
																| com.sk89q.worldedit.data.DataException | IOException e2) {
															e2.printStackTrace();
														}
													}
												}, 60L);
											}
										}
									}, 100L);
								}
							}
						} else {
							if (StartCommand.Red.contains((Player) damaged)) {
								StartCommand.Red.remove((Player) damaged);
								if (StartCommand.Red.size() == 0) {
									for (Player aop : Bukkit.getOnlinePlayers()) {
										aop.setGameMode(GameMode.ADVENTURE);
										aop.sendTitle(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Blue", ChatColor.GREEN + "has just won the game!", 20, 60, 20);
										StartCommand.teamSize = new String("NotReady");
										if (StartCommand.map.equals("SF")) {
											WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
											File SFSchematic1 = new File("plugins/WorldEdit/schematics/SFSchematic1.schematic");
											File SFSchematic2 = new File("plugins/WorldEdit/schematics/SFSchematic2.schematic");
											EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
											try {
												MCEditSchematicFormat.getFormat(SFSchematic1).load(SFSchematic1).paste(session, new Vector(0,76,0), false);
											} catch (MaxChangedBlocksException
													| com.sk89q.worldedit.data.DataException | IOException e2) {
												e2.printStackTrace();
											}
											Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
												public void run() {
													try {
														MCEditSchematicFormat.getFormat(SFSchematic2).load(SFSchematic2).paste(session, new Vector(0,76,0), false);
														StartCommand.teamSize = new String("NoGame");
														StartCommand.mode = new String("NoMode");
														StartCommand.map = new String("NoMap");
														aop.teleport((Bukkit.getServer().getWorld("world").getSpawnLocation()));
														aop.getInventory().clear();
														aop.setGameMode(GameMode.SURVIVAL);
													} catch (MaxChangedBlocksException
															| com.sk89q.worldedit.data.DataException | IOException e2) {
														e2.printStackTrace();
													}
												}
											}, 60L);
										}
									}
								}
							}
						}
					} else {
						if (StartCommand.mode.equals("Infiltration")) {
							((Player) damaged).setHealth(20);
							((Player) damaged).setGameMode(GameMode.SPECTATOR);
							damaged.teleport(new Location(w,-62,76,0));
							((Player) damaged).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 3 seconds.", 10, 20, 0);
							Bukkit.getScheduler().runTaskLater(main, new Runnable() {
								public void run() {
									((Player) damaged).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 2 seconds.", 0, 20, 0);
									Bukkit.getScheduler().runTaskLater(main, new Runnable() {
										public void run() {
											((Player) damaged).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 1 seconds.", 0, 20, 0);
											Bukkit.getScheduler().runTaskLater(main, new Runnable() {
												public void run() {
													if (!StartCommand.teamSize.equals("NoGame") || !StartCommand.teamSize.equals("NotReady")) {
														if (StartCommand.Blue.contains(damaged)) {
															((Player) damaged).setGameMode(GameMode.SURVIVAL);
															((Player) damaged).getInventory().clear();
															((HumanEntity) damaged).getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
														} else {
															if (StartCommand.Red.contains(damaged)) {
																damaged.teleport(StartCommand.RedAirBase);
																((Player) damaged).setGameMode(GameMode.SURVIVAL);
																((Player) damaged).getInventory().clear();
																((HumanEntity) damaged).getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
															} 
														}
													} else {
														damaged.teleport(Bukkit.getServer().getWorld("world").getSpawnLocation());
													}
												}
											}, 20L);
										}
									}, 20L);
								}
							}, 20L);
						}
					}
				}
			}
		}
	}

	@EventHandler
	public void teamGUIClick(InventoryClickEvent e) {

		Player player = (Player) e.getWhoClicked();

		if (ChatColor.translateAlternateColorCodes('&',e.getClickedInventory().getTitle()).equals(ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "Choose Your Team")) {
			if (e.getCurrentItem() != null) {
				e.setCancelled(true);

				ItemStack currentItem = e.getCurrentItem();
				if (e.getCurrentItem().getType() == Material.STAINED_GLASS_PANE) {
					if (currentItem.getDurability() == (short) 11) { //Blue
						if (StartCommand.teamSize.equalsIgnoreCase("NoGame")) {
							player.sendMessage("No game no play ;[ !");
						} else {
							if (StartCommand.Blue.size() == Integer.parseInt(StartCommand.teamSize)) {
								player.sendMessage("That team is full!");
							} else {
								StartCommand.Blue.add(player);
								player.sendMessage("You have joined the blue team!");
								player.closeInventory();
								player.setHealth(20);
								if (StartCommand.mode.equals("Classic")) {
									player.teleport(StartCommand.BlueStoneFortress);
									player.getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 3), new ItemStack(Material.STONE, 64), new ItemStack(Material.WOOD, 32), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
								} else {
									if (StartCommand.mode.equals("Infiltration")) {
										player.teleport(StartCommand.BlueAirBase);
										player.getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
									}
								}
							}
						}
					}  
					else if (currentItem.getDurability() == (short) 14) { //Red
						if (StartCommand.teamSize.equalsIgnoreCase("NoGame")) {
							player.sendMessage("The game hasn't started ;[ !");
						} else {
							if (StartCommand.Red.size() == Integer.parseInt(StartCommand.teamSize)) {
								player.sendMessage("That team is full!");
							} else {
								StartCommand.Red.add(player);
								player.sendMessage("You have joined the red team!");
								player.closeInventory();
								player.setHealth(20);
								if (StartCommand.mode.equals("Classic")) {
									player.teleport(StartCommand.RedStoneFortress);
									player.getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 3), new ItemStack(Material.STONE, 64), new ItemStack(Material.WOOD, 32), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
								} else {
									if (StartCommand.mode.equals("Infiltration")) {
										player.teleport(StartCommand.RedAirBase);
										player.getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
									}
								}
							}
						}
					}
				} else {
					e.setCancelled(true);
				}
			}
		} else {
			//Gamemode selection GUI handling
			if (ChatColor.translateAlternateColorCodes('&',e.getClickedInventory().getTitle()).equals(ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "Fireball Gamemodes")) {
				if (e.getCurrentItem() != null) {
					e.setCancelled(true);

					ItemStack currentItem = e.getCurrentItem();
					switch (e.getCurrentItem().getType()) {
					case FIREBALL:
						if (currentItem.getType().equals(Material.FIREBALL)) {
							player.closeInventory();
							player.openInventory(StartCommand.classicMapsGUI);
							StartCommand.mode = new String("Classic");
							for (Player aop : Bukkit.getOnlinePlayers()) {
								aop.sendMessage(player.getName() + " has chosen Classic mode.");
							}
						}
					case BANNER:
						if (currentItem.getType().equals(Material.BANNER)) {
							player.closeInventory();
							player.openInventory(StartCommand.infiltrationMapsGUI);
							StartCommand.mode = new String("Infiltration");
							for (Player aop : Bukkit.getOnlinePlayers()) {
								aop.sendMessage(player.getName() + " has chosen Infiltration mode.");
							}
						}
					default:
						break;
					}
				}
			} else {
				//Map selection GUI (classic)
				if (ChatColor.translateAlternateColorCodes('&',e.getClickedInventory().getTitle()).equals(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Classic Maps")) {
					if (e.getCurrentItem() != null) {
						e.setCancelled(true);

						e.getCurrentItem();
						if (e.getCurrentItem().getType().equals(Material.SMOOTH_BRICK)) {
							player.closeInventory();
							for (Player aop : Bukkit.getOnlinePlayers()) {
								aop.sendMessage(player.getName() + " has chosen the map Stone Fortress");
								StartCommand.map = new String("SF");
								aop.openInventory(StartCommand.chooseTeamGUI);

							}
						}
					}
				} else {
					//Map selection GUI (inflitration)
					if (ChatColor.translateAlternateColorCodes('&',e.getClickedInventory().getTitle()).equals(ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "Infiltration Maps")) {
						if (e.getCurrentItem() != null) {
							e.setCancelled(true);

							e.getCurrentItem();
							if (e.getCurrentItem().getType().equals(Material.FEATHER)) {
								player.closeInventory();
								for (Player aop : Bukkit.getOnlinePlayers()) {
									aop.sendMessage(player.getName() + " has chosen the map Airbase");
									StartCommand.map = new String("AB");
									aop.openInventory(StartCommand.chooseTeamGUI);

								}
							}
						}
					}
				}
			}
		}
	}

	@EventHandler
	public void AutoArmor(PlayerMoveEvent e){
		if (!StartCommand.Blue.isEmpty() && !StartCommand.Red.isEmpty()) {
			for(ItemStack item: e.getPlayer().getInventory().getContents()){
				if(item.getType().toString().toLowerCase().contains("helmet") && e.getPlayer().getInventory().getHelmet() == null){
					e.getPlayer().getInventory().setHelmet(item);
					e.getPlayer().getInventory().remove(item);
				}
				if(item.getType().toString().toLowerCase().contains("chestplate") && e.getPlayer().getInventory().getChestplate() == null){
					e.getPlayer().getInventory().setChestplate(item);
					e.getPlayer().getInventory().remove(item);
				}
				if(item.getType().toString().toLowerCase().contains("leggings") && e.getPlayer().getInventory().getLeggings() == null){
					e.getPlayer().getInventory().setLeggings(item);
					e.getPlayer().getInventory().remove(item);
				}
				if(item.getType().toString().toLowerCase().contains("boots") && e.getPlayer().getInventory().getBoots() == null){
					e.getPlayer().getInventory().setBoots(item);
					e.getPlayer().getInventory().remove(item);
				}
			}
		}
	}

	/**
	 * Main Handling for the minigame
	 * @param e
	 */

	@EventHandler
	public void CheckYCoord(PlayerMoveEvent e) {

		Player player = e.getPlayer();
		World w = null;
		if(Bukkit.getServer().getWorld("Fire") == null){
			w = Bukkit.getServer().getWorld("world");
		} else {
			w = Bukkit.getServer().getWorld("Fire");
		}
		
		
		if (!StartCommand.teamSize.equals("NotReady") || !StartCommand.teamSize.equals("NoGame")) {
			if(player.getLocation().getY() >= 55 && player.getLocation().getY() <= 65) {
				if (StartCommand.mode.equals("Classic")) {
					//  							((Player) player).sendTitle(ChatColor.RED + "You have just died!", "", 20, 40, 20);
					((Player) player).setHealth(20);
					StartCommand.Spectator.add((Player) player);
					((Player) player).setGameMode(GameMode.SPECTATOR);
					player.teleport(new Location(w, 0, 76, 0));
					if (StartCommand.Blue.contains((Player) player)) {
						StartCommand.Blue.remove((Player) player);
						if (StartCommand.Blue.size() == 0) {
							player.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
							StartCommand.teamSize = new String("NotReady");
							
							
							
							
							Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
								public void run() {
									World w = null;
									if(Bukkit.getServer().getWorld("Fire") == null){
										w = Bukkit.getServer().getWorld("world");
									} else {
										w = Bukkit.getServer().getWorld("Fire");
									}
									StartCommand.Blue.clear();
									StartCommand.Red.clear();
									player.teleport((Bukkit.getServer().getWorld("world").getSpawnLocation()));
									player.getInventory().clear();
									if (StartCommand.map.equals("SF")) {
										ArenaManager.pasteArena("SFSchematic1", "SFSchematic2", w, new Vector(0, 76,0),main);
									}
								}
							}, 100L);
						}
					} else {
						if (StartCommand.Red.contains((Player) player)) {
							StartCommand.Red.remove((Player) player);
							if (StartCommand.Red.size() == 0) {
								for (Player aop1 : Bukkit.getOnlinePlayers()) {
									aop1.sendTitle(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Blue", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
									StartCommand.teamSize = new String("NotReady");
									Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
										public void run() {
											World w = null;
											if(Bukkit.getServer().getWorld("Fire") == null){
												w = Bukkit.getServer().getWorld("world");
											} else {
												w = Bukkit.getServer().getWorld("Fire");
											}
											StartCommand.Blue.clear();
											StartCommand.Red.clear();
											player.teleport((Bukkit.getServer().getWorld("world").getSpawnLocation()));
											player.getInventory().clear();
											if (StartCommand.map.equals("SF")) {
												WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
												File SFSchematic1 = new File("plugins/WorldEdit/schematics/SFSchematic1.schematic");
												File SFSchematic2 = new File("plugins/WorldEdit/schematics/SFSchematic2.schematic");
												EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
												try {
													MCEditSchematicFormat.getFormat(SFSchematic1).load(SFSchematic1).paste(session, new Vector(0,76,0), false);
												} catch (MaxChangedBlocksException
														| com.sk89q.worldedit.data.DataException | IOException e2) {
													e2.printStackTrace();
												}
												Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
													public void run() {
														try {
															MCEditSchematicFormat.getFormat(SFSchematic2).load(SFSchematic2).paste(session, new Vector(0,76,0), false);
															StartCommand.teamSize = new String("NoGame");
															StartCommand.mode = new String("NoMode");
															StartCommand.map = new String("NoMap");
														} catch (MaxChangedBlocksException
																| com.sk89q.worldedit.data.DataException | IOException e2) {
															e2.printStackTrace();
														}
													}
												}, 60L);
											}
										}
									}, 100L);
								}
							}
						}
					}
				} else {
					if (StartCommand.mode.equals("Infiltration")) {
						((Player) player).setHealth(20);
						((Player) player).setGameMode(GameMode.SPECTATOR);
						if(Bukkit.getServer().getWorld("Fire") == null){
							player.teleport(new Location(Bukkit.getServer().getWorld("world"),-62,76,0));
						} else {
							player.teleport(new Location(w,-62,76,0));
						}
						((Player) player).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 3 seconds.", 10, 20, 0);
						if (player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-1,player.getLocation().getBlockZ()).getType().equals(Material.SLIME_BLOCK) && player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-2,player.getLocation().getBlockZ()).getType().equals(Material.CONCRETE) || player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-2,player.getLocation().getBlockZ()).getType().equals(Material.SLIME_BLOCK) && player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-3,player.getLocation().getBlockZ()).getType().equals(Material.CONCRETE)) {
							player.getWorld().spawnEntity(player.getLocation(), EntityType.PRIMED_TNT);
							player.getWorld().spawnEntity(player.getLocation(), EntityType.PRIMED_TNT);
							player.getWorld().spawnEntity(player.getLocation(), EntityType.PRIMED_TNT);
							player.getWorld().spawnEntity(player.getLocation(), EntityType.PRIMED_TNT);
							player.getWorld().spawnEntity(player.getLocation(), EntityType.PRIMED_TNT);
							Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
								public void run() {
									((Player) player).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 2 seconds.", 0, 20, 0);
									Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
										public void run() {
											((Player) player).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 1 seconds.", 0, 20, 0);
											Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
												public void run() {
													if (!StartCommand.teamSize.equals("NoGame") || !StartCommand.teamSize.equals("NotReady")) {
														if (StartCommand.Blue.contains(player)) {
															player.teleport(StartCommand.BlueAirBase);
															((Player) player).setGameMode(GameMode.SURVIVAL);
															((Player) player).getInventory().clear();
															((HumanEntity) player).getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
														} else {
															if (StartCommand.Red.contains(player)) {
																player.teleport(StartCommand.RedAirBase);
																((Player) player).setGameMode(GameMode.SURVIVAL);
																((Player) player).getInventory().clear();
																((HumanEntity) player).getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
															} 
														}
													} else {
														if(Bukkit.getServer().getWorld("Fire") == null){
															player.teleport(new Location(Bukkit.getServer().getWorld("world"),-62,76,0));
														} else {
															World w = null;
															if(Bukkit.getServer().getWorld("Fire") == null){
																w = Bukkit.getServer().getWorld("world");
															} else {
																w = Bukkit.getServer().getWorld("Fire");
															}
															player.teleport(new Location(w,-62,76,0));
														}
													}
												}
											}, 20L);
										}
									}, 20L);
								}
							}, 20L);
						} else {
							Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
								public void run() {
									((Player) player).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 2 seconds.", 0, 20, 0);
									Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
										public void run() {
											((Player) player).sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 1 seconds.", 0, 20, 0);
											Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
												public void run() {
													if (!StartCommand.teamSize.equals("NoGame") || !StartCommand.teamSize.equals("NotReady")) {
														if (StartCommand.Blue.contains(player)) {
															player.teleport(StartCommand.BlueAirBase);
															((Player) player).setGameMode(GameMode.SURVIVAL);
															((Player) player).getInventory().clear();
															((HumanEntity) player).getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
														} else {
															if (StartCommand.Red.contains(player)) {
																player.teleport(StartCommand.RedAirBase);
																((Player) player).setGameMode(GameMode.SURVIVAL);
																((Player) player).getInventory().clear();
																((HumanEntity) player).getInventory().addItem(new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1));
															} 
														}
													} else {
														if(Bukkit.getServer().getWorld("Fire") == null){
															player.teleport(new Location(Bukkit.getServer().getWorld("world"),-62,76,0));
														} else {
															World w = null;
															if(Bukkit.getServer().getWorld("Fire") == null){
																w = Bukkit.getServer().getWorld("world");
															} else {
																w = Bukkit.getServer().getWorld("Fire");
															}
															player.teleport(new Location(w,-62,76,0));
														}
													}
												}
											}, 20L);
										}
									}, 20L);
								}
							}, 20L);
						}

					}
				}
			}
		}

	}
	
	

	@EventHandler
	public void JetMachineGunClick(PlayerInteractEvent e) {

		Player player = (Player) e.getPlayer();

		if (!StartCommand.teamSize.equals("NoGame") || !StartCommand.teamSize.equals("NotReady")) {
			if (StartCommand.mode.equals("Infiltration")) {
				if (StartCommand.map.equals("AB")) {
					if (player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-1,player.getLocation().getBlockZ()).getType().equals(Material.SLIME_BLOCK)) {
						if (player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-2,player.getLocation().getBlockZ()).getType().equals(Material.CONCRETE)) {
							if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
								if (main.machineGunCooldown.contains(player)) {
								} else {
									player.launchProjectile(Arrow.class);
									main.machineGunCooldown.add(player);
									//Begining of cooldown
									Bukkit.getScheduler().runTaskLater(main, new Runnable(){
										@Override
										public void run() {
											Main.rm.sendActionBar(player, "§2You can use §eMachineGun§2 again in §e5s");
											Bukkit.getScheduler().runTaskLater(main, new Runnable(){
												@Override
												public void run() {
													Main.rm.sendActionBar(player, "§2You can use §eMachineGun§2 again in §e4s");
													Bukkit.getScheduler().runTaskLater(main, new Runnable(){
														@Override
														public void run() {
															Main.rm.sendActionBar(player, "§2You can use §eMachineGun§2 again in §e3s");
															Bukkit.getScheduler().runTaskLater(main, new Runnable(){
																@Override
																public void run() {
																	Main.rm.sendActionBar(player, "§2You can use §eMachineGun§2 again in §e2s");
																	Bukkit.getScheduler().runTaskLater(main, new Runnable(){
																		@Override
																		public void run() {
																			Main.rm.sendActionBar(player, "§2You can use §eMachineGun§2 again in §e1s");
																			Bukkit.getScheduler().runTaskLater(main, new Runnable(){
																				@Override
																				public void run() {
																					Main.rm.sendActionBar(player, "§2You can use §eMachineGun§2 again §enow");
																					main.machineGunCooldown.remove(player);
																				}
																			}, 20L);}}, 20L);}}, 20L);}}, 20L);}}, 20L);}}, 20L);
								}
							}
						}
					}
				}
			}
		}

	}

	@EventHandler
	public void JetCannonClick(PlayerInteractEvent e) {

		final Player player = (Player) e.getPlayer();

		if (!StartCommand.teamSize.equals("NoGame") || !StartCommand.teamSize.equals("NotReady")) {
			if (StartCommand.mode.equals("Infiltration")) {
				if (StartCommand.map.equals("AB")) {
					if (player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-1,player.getLocation().getBlockZ()).getType().equals(Material.SLIME_BLOCK)) {
						if (player.getWorld().getBlockAt(player.getLocation().getBlockX(),player.getLocation().getBlockY()-2,player.getLocation().getBlockZ()).getType().equals(Material.CONCRETE)) {
							if(e.getAction() == Action.LEFT_CLICK_AIR) {

								if (main.cannonCooldown.contains(player)) {
								} else {
									player.launchProjectile(Fireball.class);
									main.cannonCooldown.add(player);
									player.sendMessage("Fireball shot! Wait 5 seconds to shoot again.");
									//Begining of cooldown
									Bukkit.getScheduler().runTaskLater(main, new Runnable(){
										@Override
										public void run() {
											Main.rm.sendActionBar(player, "§2You can use §eFireball§2 again in §e5s");
											Bukkit.getScheduler().runTaskLater(main, new Runnable(){
												@Override
												public void run() {
													Main.rm.sendActionBar(player, "§2You can use §eFireball§2 again in §e4s");
													Bukkit.getScheduler().runTaskLater(main, new Runnable(){
														@Override
														public void run() {
															Main.rm.sendActionBar(player, "§2You can use §eFireball§2 again in §e3s");
															Bukkit.getScheduler().runTaskLater(main, new Runnable(){
																@Override
																public void run() {
																	Main.rm.sendActionBar(player, "§2You can use §eFireball§2 again in §e2s");
																	Bukkit.getScheduler().runTaskLater(main, new Runnable(){
																		@Override
																		public void run() {
																			Main.rm.sendActionBar(player, "§2You can use §eFireball§2 again in §e1s");
																			Bukkit.getScheduler().runTaskLater(main, new Runnable(){
																				@Override
																				public void run() {
																					Main.rm.sendActionBar(player, "§2You can use §eFireball§2 again §enow");
																					main.cannonCooldown.remove(player);
																				}
																			}, 20L);}}, 20L);}}, 20L);}}, 20L);}}, 20L);}}, 20L);
									//end of the cannon cooldown system
								}
							}
						}
					}
				}
			}
		}

	}

	@EventHandler
	public void RespawnJet(PlayerInteractEvent e) {

		Player player = (Player) e.getPlayer();

		if (StartCommand.map.equals("AB")) {
			if (e.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if (e.getClickedBlock().getType().equals(Material.STONE_BUTTON)) {
					World w = null;
					if(Bukkit.getServer().getWorld("Fire") == null){
						w = Bukkit.getServer().getWorld("world");
					} else {
						w = Bukkit.getServer().getWorld("Fire");
					}
					if (e.getClickedBlock().getLocation().equals(new Location(w, -57, 77, 49))) {  //Blue button
						if (main.respawnBlueJetCooldown.containsKey(player) && (main.respawnBlueJetCooldown.get(player) > System.currentTimeMillis())) {
							long longRemaining = main.respawnBlueJetCooldown.get(player) - System.currentTimeMillis();
							int intRemaining = (int) (longRemaining / 1000);
							player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
						} else {
							main.respawnBlueJetCooldown.put(player, (long) (System.currentTimeMillis() + (60 * 1000)));
							player.sendMessage("Jet Spawned!");
							WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
							File ABBJet2 = new File("plugins/WorldEdit/schematics/ABBJet2.schematic");
							EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(Bukkit.getServer().getWorld("Fire")), 1000000);
							try {
								MCEditSchematicFormat.getFormat(ABBJet2).load(ABBJet2).paste(session, new Vector(-55, 77, 65), false);
							} catch (MaxChangedBlocksException
									| com.sk89q.worldedit.data.DataException | IOException e2) {
								// TODO Auto-generated catch block
								e2.printStackTrace();
							}
						}
					} else {
						if (e.getClickedBlock().getLocation().equals(new Location(w, -67, 77, 49))) { //Blue button 2
							if (main.respawnBlueJetCooldown2.containsKey(player) && (main.respawnBlueJetCooldown2.get(player) > System.currentTimeMillis())) {
								long longRemaining = main.respawnBlueJetCooldown2.get(player) - System.currentTimeMillis();
								int intRemaining = (int) (longRemaining / 1000);
								player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
							} else {
								main.respawnBlueJetCooldown2.put(player, (long) (System.currentTimeMillis() + (60 * 1000)));
								player.sendMessage("Jet Spawned!");
								WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
								File ABBJet2 = new File("plugins/WorldEdit/schematics/ABBJet2.schematic");
								EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
								try {
									MCEditSchematicFormat.getFormat(ABBJet2).load(ABBJet2).paste(session, new Vector(-69, 77, 65), false);
								} catch (MaxChangedBlocksException
										| com.sk89q.worldedit.data.DataException | IOException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}
							}
						} else {
							if (e.getClickedBlock().getLocation().equals(new Location(w, -57, 77, -49))) {  //Red button
								if (main.respawnRedJetCooldown.containsKey(player) && (main.respawnRedJetCooldown.get(player) > System.currentTimeMillis())) {
									long longRemaining = main.respawnRedJetCooldown.get(player) - System.currentTimeMillis();
									int intRemaining = (int) (longRemaining / 1000);
									player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
								} else {
									main.respawnRedJetCooldown.put(player, (long) (System.currentTimeMillis() + (60 * 1000)));
									player.sendMessage("Jet Spawned!");
									WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
									File ABRJet2 = new File("plugins/WorldEdit/schematics/ABRJet2.schematic");
									EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
									try {
										MCEditSchematicFormat.getFormat(ABRJet2).load(ABRJet2).paste(session, new Vector(-55, 77, -65), false);
									} catch (MaxChangedBlocksException
											| com.sk89q.worldedit.data.DataException | IOException e2) {
										// TODO Auto-generated catch block
										e2.printStackTrace();
									}
								}
							} else {
								if (e.getClickedBlock().getLocation().equals(new Location(w, -67, 77, -49))) { //Red button 2
									if (main.respawnRedJetCooldown2.containsKey(player) && (main.respawnRedJetCooldown2.get(player) > System.currentTimeMillis())) {
										long longRemaining = main.respawnRedJetCooldown2.get(player) - System.currentTimeMillis();
										int intRemaining = (int) (longRemaining / 1000);
										player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
									} else { 
										main.respawnRedJetCooldown2.put(player, (long) (System.currentTimeMillis() + (60 * 1000)));
										player.sendMessage("Jet Spawned!");
										WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit"); 
										File ABRJet2 = new File("plugins/WorldEdit/schematics/ABRJet2.schematic");
										EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
										try {
											MCEditSchematicFormat.getFormat(ABRJet2).load(ABRJet2).paste(session, new Vector(-69, 77, -65), false);
										} catch (MaxChangedBlocksException
												| com.sk89q.worldedit.data.DataException | IOException e2) {
											// TODO Auto-generated catch block
											e2.printStackTrace();
										}
									}

								}
							}
						}
					}
				}
			}
		}
	}

	@EventHandler
	public void cancelBuilding(BlockPlaceEvent e) {

		Player player = e.getPlayer();

		if (!StartCommand.teamSize.equals("NoGame") || !StartCommand.teamSize.equals("NotReady")) {
			if (StartCommand.mode.equals("Infiltration")) {
				if(player.getLocation().getX() >= -92 && player.getLocation().getX() <= -32 && player.getLocation().getY() >= 55 && player.getLocation().getY() <= 101 && player.getLocation().getZ() >= -21 && player.getLocation().getZ() <= 21) {
					e.setCancelled(true);
					player.sendMessage("You cannot build here!");
				}
			}
		}
	}
}


