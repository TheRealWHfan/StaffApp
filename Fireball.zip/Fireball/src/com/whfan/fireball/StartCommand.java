package com.whfan.fireball;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class StartCommand
  implements CommandExecutor
{
  private static Main main;
  public static String map = "NoMap";
  public static String rawTeamSize = "0";
  public static String teamSize = "0";
  public static String infilTeamSize = "0";
  public static String constructionTeamSize = "0";
  public static String mode = "NoMode";
  public static GameState state = GameState.RESETTING;
  public static GameState infilState = GameState.RESETTING;
  public static GameState constructionState = GameState.RESETTING;
  public static Location BlueSkyIsland = new Location(Bukkit.getServer().getWorld("Fire"), 0.5D, 80.0D, 217.5D);
  public static Location RedSkyIsland = new Location(Bukkit.getServer().getWorld("Fire"), 0.5D, 80.0D, 143.5D);
  public static Location BlueSkyIslandK = new Location(Bukkit.getServer().getWorld("Fire"), 0.5D, 80.0D, 219.5D);
  public static Location RedSkyIslandK = new Location(Bukkit.getServer().getWorld("Fire"), 0.5D, 80.0D, 141.5D);
  public static Location BlueStoneFortress = new Location(Bukkit.getServer().getWorld("Fire"), 0.0D, 77.0D, 41.0D);
  public static Location RedStoneFortress = new Location(Bukkit.getServer().getWorld("Fire"), 0.0D, 77.0D, -41.0D);
  public static Location BlueAirBase = new Location(Bukkit.getServer().getWorld("Fire"), -62.0D, 77.0D, 53.0D);
  public static Location RedAirBase = new Location(Bukkit.getServer().getWorld("Fire"), -62.0D, 77.0D, -53.0D);
  public static ArrayList<Player> Spectator = new ArrayList();
  public static ArrayList<Player> Blue = new ArrayList();
  public static ArrayList<Player> Red = new ArrayList();
  public static ArrayList<Player> BlueDead = new ArrayList();
  public static ArrayList<Player> RedDead = new ArrayList();
  public static Inventory chooseTeamGUI = Bukkit.createInventory(null, 27, ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "Choose Your Team");
  
  public StartCommand(Main main) {
    main = main;
    ItemStack glassPane = new ItemStack(Material.STAINED_GLASS_PANE);
    ItemMeta glassPaneMeta = glassPane.getItemMeta();
    glassPaneMeta.setDisplayName(" ");
    glassPane.setItemMeta(glassPaneMeta);
    
    ItemStack glassPanePink = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)6);
    ItemMeta glassPanePinkMeta = glassPanePink.getItemMeta();
    glassPanePinkMeta.setDisplayName(" ");
    glassPanePink.setItemMeta(glassPanePinkMeta);
    
    ItemStack blue = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)11);
    ItemMeta blueMeta = blue.getItemMeta();
    blueMeta.setDisplayName(ChatColor.BLUE + "Blue Team");
    blue.setItemMeta(blueMeta);
    
    ItemStack red = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)14);
    ItemMeta redMeta = red.getItemMeta();
    redMeta.setDisplayName(ChatColor.DARK_RED + "Red Team");
    red.setItemMeta(redMeta);
    
    chooseTeamGUI.setItem(0, glassPanePink);
    chooseTeamGUI.setItem(1, glassPane);
    chooseTeamGUI.setItem(2, glassPane);
    chooseTeamGUI.setItem(3, glassPane);
    chooseTeamGUI.setItem(4, glassPane);
    chooseTeamGUI.setItem(5, glassPane);
    chooseTeamGUI.setItem(6, glassPane);
    chooseTeamGUI.setItem(7, glassPane);
    chooseTeamGUI.setItem(8, glassPanePink);
    chooseTeamGUI.setItem(9, glassPane);
    chooseTeamGUI.setItem(10, glassPane);
    chooseTeamGUI.setItem(11, blue);
    chooseTeamGUI.setItem(12, glassPane);
    chooseTeamGUI.setItem(13, glassPane);
    chooseTeamGUI.setItem(14, glassPane);
    chooseTeamGUI.setItem(15, red);
    chooseTeamGUI.setItem(16, glassPane);
    chooseTeamGUI.setItem(17, glassPane);
    chooseTeamGUI.setItem(18, glassPanePink);
    chooseTeamGUI.setItem(19, glassPane);
    chooseTeamGUI.setItem(20, glassPane);
    chooseTeamGUI.setItem(21, glassPane);
    chooseTeamGUI.setItem(22, glassPane);
    chooseTeamGUI.setItem(23, glassPane);
    chooseTeamGUI.setItem(24, glassPane);
    chooseTeamGUI.setItem(25, glassPane);
    chooseTeamGUI.setItem(26, glassPanePink);
    
    ItemStack glassPane1 = new ItemStack(Material.STAINED_GLASS_PANE);
    ItemMeta glassPaneMeta1 = glassPane1.getItemMeta();
    glassPaneMeta1.setDisplayName(" ");
    glassPane1.setItemMeta(glassPaneMeta1);
    
    ItemStack glassPanePink1 = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)6);
    ItemMeta glassPanePinkMeta1 = glassPanePink1.getItemMeta();
    glassPanePinkMeta1.setDisplayName(" ");
    glassPanePink1.setItemMeta(glassPanePinkMeta1);
    
    ItemStack classic = new ItemStack(Material.FIREBALL, 1);
    ItemMeta classicMeta = classic.getItemMeta();
    classicMeta.setDisplayName(ChatColor.DARK_BLUE + "Classic Mode");
    classic.setItemMeta(classicMeta);
    
    ItemStack infiltration = new ItemStack(Material.BANNER, 1, (short)7);
    ItemMeta infiltrationMeta = infiltration.getItemMeta();
    infiltrationMeta.setDisplayName(ChatColor.DARK_GREEN + "Infiltration Mode");
    infiltration.setItemMeta(infiltrationMeta);
    
    ItemStack construction = new ItemStack(Material.IRON_PICKAXE);
    ItemMeta constructionMeta = construction.getItemMeta();
    constructionMeta.setDisplayName(ChatColor.GOLD + "Construction Mode");
    construction.setItemMeta(constructionMeta);
    
    chooseGamemodeGUI.setItem(0, glassPanePink1);
    chooseGamemodeGUI.setItem(1, glassPane1);
    chooseGamemodeGUI.setItem(2, glassPane1);
    chooseGamemodeGUI.setItem(3, glassPane1);
    chooseGamemodeGUI.setItem(4, glassPane1);
    chooseGamemodeGUI.setItem(5, glassPane1);
    chooseGamemodeGUI.setItem(6, glassPane1);
    chooseGamemodeGUI.setItem(7, glassPane1);
    chooseGamemodeGUI.setItem(8, glassPanePink1);
    chooseGamemodeGUI.setItem(9, glassPane1);
    chooseGamemodeGUI.setItem(11, construction);
    chooseGamemodeGUI.setItem(13, classic);
    chooseGamemodeGUI.setItem(15, infiltration);
    chooseGamemodeGUI.setItem(17, glassPane1);
    chooseGamemodeGUI.setItem(18, glassPanePink1);
    chooseGamemodeGUI.setItem(19, glassPane1);
    chooseGamemodeGUI.setItem(20, glassPane1);
    chooseGamemodeGUI.setItem(21, glassPane1);
    chooseGamemodeGUI.setItem(22, glassPane1);
    chooseGamemodeGUI.setItem(23, glassPane1);
    chooseGamemodeGUI.setItem(24, glassPane1);
    chooseGamemodeGUI.setItem(25, glassPane1);
    chooseGamemodeGUI.setItem(26, glassPanePink1);
    
    ItemStack glassPaneClassic = new ItemStack(Material.STAINED_GLASS_PANE);
    ItemMeta glassPaneClassicMeta = glassPaneClassic.getItemMeta();
    glassPaneClassicMeta.setDisplayName(" ");
    glassPaneClassic.setItemMeta(glassPaneClassicMeta);
    
    ItemStack glassPaneClassicPink = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)6);
    ItemMeta glassPaneClassicPinkMeta = glassPaneClassicPink.getItemMeta();
    glassPaneClassicPinkMeta.setDisplayName(" ");
    glassPaneClassicPink.setItemMeta(glassPaneClassicPinkMeta);
    
    ItemStack SF = new ItemStack(Material.SMOOTH_BRICK, 1);
    ItemMeta SFMeta = SF.getItemMeta();
    SFMeta.setDisplayName(ChatColor.BLUE + "Stone Fortress");
    SF.setItemMeta(SFMeta);
    
    classicMapsGUI.setItem(0, glassPaneClassicPink);
    classicMapsGUI.setItem(1, glassPaneClassic);
    classicMapsGUI.setItem(2, glassPaneClassic);
    classicMapsGUI.setItem(3, glassPaneClassic);
    classicMapsGUI.setItem(4, glassPaneClassic);
    classicMapsGUI.setItem(5, glassPaneClassic);
    classicMapsGUI.setItem(6, glassPaneClassic);
    classicMapsGUI.setItem(7, glassPaneClassic);
    classicMapsGUI.setItem(8, glassPaneClassicPink);
    classicMapsGUI.setItem(9, glassPaneClassic);
    classicMapsGUI.setItem(13, SF);
    classicMapsGUI.setItem(17, glassPaneClassic);
    classicMapsGUI.setItem(18, glassPaneClassicPink);
    classicMapsGUI.setItem(19, glassPaneClassic);
    classicMapsGUI.setItem(20, glassPaneClassic);
    classicMapsGUI.setItem(21, glassPaneClassic);
    classicMapsGUI.setItem(22, glassPaneClassic);
    classicMapsGUI.setItem(23, glassPaneClassic);
    classicMapsGUI.setItem(24, glassPaneClassic);
    classicMapsGUI.setItem(25, glassPaneClassic);
    classicMapsGUI.setItem(26, glassPaneClassicPink);
    
    ItemStack glassPaneInfil = new ItemStack(Material.STAINED_GLASS_PANE);
    ItemMeta glassPaneInfilMeta = glassPaneInfil.getItemMeta();
    glassPaneInfilMeta.setDisplayName(" ");
    glassPaneInfil.setItemMeta(glassPaneInfilMeta);
    
    ItemStack glassPaneInfilPink = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)6);
    ItemMeta glassPaneInfilPinkMeta = glassPaneInfilPink.getItemMeta();
    glassPaneInfilPinkMeta.setDisplayName(" ");
    glassPaneInfilPink.setItemMeta(glassPaneInfilPinkMeta);
    
    ItemStack AB = new ItemStack(Material.FEATHER, 1);
    ItemMeta ABMeta = AB.getItemMeta();
    ABMeta.setDisplayName(ChatColor.BLUE + "Airbase");
    AB.setItemMeta(ABMeta);
    
    infiltrationMapsGUI.setItem(0, glassPaneInfilPink);
    infiltrationMapsGUI.setItem(1, glassPaneInfil);
    infiltrationMapsGUI.setItem(2, glassPaneInfil);
    infiltrationMapsGUI.setItem(3, glassPaneInfil);
    infiltrationMapsGUI.setItem(4, glassPaneInfil);
    infiltrationMapsGUI.setItem(5, glassPaneInfil);
    infiltrationMapsGUI.setItem(6, glassPaneInfil);
    infiltrationMapsGUI.setItem(7, glassPaneInfil);
    infiltrationMapsGUI.setItem(8, glassPaneInfilPink);
    infiltrationMapsGUI.setItem(9, glassPaneInfil);
    infiltrationMapsGUI.setItem(13, AB);
    infiltrationMapsGUI.setItem(17, glassPaneInfil);
    infiltrationMapsGUI.setItem(18, glassPaneInfilPink);
    infiltrationMapsGUI.setItem(19, glassPaneInfil);
    infiltrationMapsGUI.setItem(20, glassPaneInfil);
    infiltrationMapsGUI.setItem(21, glassPaneInfil);
    infiltrationMapsGUI.setItem(22, glassPaneInfil);
    infiltrationMapsGUI.setItem(23, glassPaneInfil);
    infiltrationMapsGUI.setItem(24, glassPaneInfil);
    infiltrationMapsGUI.setItem(25, glassPaneInfil);
    infiltrationMapsGUI.setItem(26, glassPaneInfilPink);
    
    ItemStack SkyIslands = new ItemStack(Material.GRASS, 1);
    ItemMeta SkyIslandsMeta = SkyIslands.getItemMeta();
    SkyIslandsMeta.setDisplayName(ChatColor.DARK_GREEN + "SkyIslands");
    SkyIslands.setItemMeta(SkyIslandsMeta);
    
    constructionMapsGUI.setItem(0, glassPaneInfilPink);
    constructionMapsGUI.setItem(1, glassPaneInfil);
    constructionMapsGUI.setItem(2, glassPaneInfil);
    constructionMapsGUI.setItem(3, glassPaneInfil);
    constructionMapsGUI.setItem(4, glassPaneInfil);
    constructionMapsGUI.setItem(5, glassPaneInfil);
    constructionMapsGUI.setItem(6, glassPaneInfil);
    constructionMapsGUI.setItem(7, glassPaneInfil);
    constructionMapsGUI.setItem(8, glassPaneInfilPink);
    constructionMapsGUI.setItem(9, glassPaneInfil);
    constructionMapsGUI.setItem(13, SkyIslands);
    constructionMapsGUI.setItem(17, glassPaneInfil);
    constructionMapsGUI.setItem(18, glassPaneInfilPink);
    constructionMapsGUI.setItem(19, glassPaneInfil);
    constructionMapsGUI.setItem(20, glassPaneInfil);
    constructionMapsGUI.setItem(21, glassPaneInfil);
    constructionMapsGUI.setItem(22, glassPaneInfil);
    constructionMapsGUI.setItem(23, glassPaneInfil);
    constructionMapsGUI.setItem(24, glassPaneInfil);
    constructionMapsGUI.setItem(25, glassPaneInfil);
    constructionMapsGUI.setItem(26, glassPaneInfilPink);
  }
  
  public static Inventory chooseGamemodeGUI = Bukkit.createInventory(null, 27, ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "Fireball Gamemodes");
  public static Inventory classicMapsGUI = Bukkit.createInventory(null, 27, ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Classic Maps");
  public static Inventory infiltrationMapsGUI = Bukkit.createInventory(null, 27, ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "Infiltration Maps");
  public static Inventory constructionMapsGUI = Bukkit.createInventory(null, 27, ChatColor.GOLD + "" + ChatColor.BOLD + "Construction Maps");
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    rawTeamSize = new String(args[0].toString());
    
    Player cmdsender = (Player)sender;
    if (main.stoneFortress.contains(cmdsender))
    {
      cmdsender.sendMessage("You're already in a match! Do /gameleave if you wish to leave your match.");
    }
    else if (main.airBase.contains(cmdsender))
    {
      cmdsender.sendMessage("You're already in a match! Do /gameleave if you wish to leave your match.");
    }
    else if (state.equals(GameState.INGAME))
    {
      cmdsender.sendMessage("All games are full (the developers are adding more games)!");
    }
    else if (teamSize == "-1")
    {
      cmdsender.sendMessage("The map is still loading! Please wait.");
    }
    else
    {
      if (args.length != 1)
      {
        cmdsender.sendMessage("Invalid syntax! Usage: /gamestart <teamSize>");
        return true;
      }
      try
      {
        if ((Integer.parseInt(args[0]) <= 10) && (Integer.parseInt(args[0]) > 0))
        {
          cmdsender.openInventory(chooseGamemodeGUI);
          return true;
        }
        cmdsender.sendMessage("Invalid argument! Options are 1-10");
        return true;
      }
      catch (NumberFormatException e)
      {
        cmdsender.sendMessage("Invalid argument! Options are 1-10");
        return true;
      }
    }
    return false;
  }
}
