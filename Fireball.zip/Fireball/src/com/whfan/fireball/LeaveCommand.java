package com.whfan.fireball;

import com.sk89q.worldedit.Vector;
import java.util.ArrayList;
import java.util.HashMap;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.PlayerInventory;

public class LeaveCommand
  implements CommandExecutor
{
  private static Main main;
  
  public LeaveCommand(Main main)
  {
    main = main;
  }
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player player = (Player)sender;
    if (main.stoneFortress.contains(player))
    {
      player.sendMessage("You have left your match!");
      player.getInventory().clear();
      player.setHealth(20.0D);
      player.teleport(Bukkit.getWorld("world").getSpawnLocation());
      if (StartCommand.state.equals(GameState.INGAME))
      {
        if (main.stoneFortress.contains(player))
        {
          if (main.stoneFortressB.contains(player)) {
            main.stoneFortressBDead.add(player);
          } else {
            main.stoneFortressRDead.add(player);
          }
          for (Player aop : Bukkit.getOnlinePlayers()) {
            if (main.stoneFortress.contains(aop)) {
              aop.sendMessage(player.getName() + " has forfeited!");
            }
          }
          if (main.stoneFortressR.size() == main.stoneFortressRDead.size()) {
            EventSystem.ClassicWin(Integer.valueOf(1), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
          }
          if (main.stoneFortressB.size() == main.stoneFortressBDead.size()) {
            EventSystem.ClassicWin(Integer.valueOf(2), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
          }
          main.gameMode.remove(player);
          main.stoneFortress.remove(player);
        }
      }
      else {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if (main.stoneFortress.contains(aop))
          {
            main.gameMode.remove(player);
            main.stoneFortress.remove(player);
            aop.sendMessage(player.getName() + " has left the match (" + main.stoneFortress.size() + "/" + Integer.parseInt(StartCommand.teamSize) * 2 + ")!");
            if (main.stoneFortressB.contains(player)) {
              main.stoneFortressB.remove(player);
            }
            if (main.stoneFortressR.contains(player)) {
              main.stoneFortressB.remove(player);
            }
          }
        }
      }
    }
    else if (main.airBase.contains(player))
    {
      player.sendMessage("You have left your match!");
      player.teleport(Bukkit.getWorld("world").getSpawnLocation());
      if (StartCommand.infilState.equals(GameState.INGAME))
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          aop.sendMessage(player.getName() + " has fortfeited!");
        }
        if (main.airBaseB.contains(player)) {
          player.getWorld().getBlockAt(-62, 84, -34).breakNaturally();
        }
        if (main.airBaseB.contains(player)) {
          player.getWorld().getBlockAt(-62, 84, 34).breakNaturally();
        }
        main.gameMode.remove(player);
        main.airBase.remove(player);
      }
      else
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if (main.airBase.contains(aop))
          {
            main.gameMode.remove(player);
            main.airBase.remove(player);
            aop.sendMessage(player.getName() + " has left the match (" + main.airBase.size() + "/" + Integer.parseInt(StartCommand.infilTeamSize) * 2 + ")!");
            if (main.airBaseB.contains(player)) {
              main.airBaseB.remove(player);
            }
            if (main.airBaseR.contains(player)) {
              main.airBaseB.remove(player);
            }
          }
        }
      }
    }
    else
    {
      player.sendMessage("You aren't in a match!");
    }
    return false;
  }
}
