package com.whfan.fireball;

import com.sk89q.worldedit.CuboidClipboard;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.EditSessionFactory;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.data.DataException;
import com.sk89q.worldedit.schematic.MCEditSchematicFormat;
import com.sk89q.worldedit.schematic.SchematicFormat;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerEggThrowEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.PluginManager;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitScheduler;

public class EventSystem
  implements Listener
{
  private static Main main;
  
  public EventSystem(Main main)
  {
    main = main;
  }
  
  public static void InfiltrationWin()
  {
    for (Player blueTeamPlayer : main.airBaseB) {
      if (Bukkit.getWorld("Fire").getBlockAt(-62, 84, -34).getType().equals(Material.AIR))
      {
        StartCommand.infilState = GameState.RESETTING;
        for (Player redTeamPlayer : main.airBaseR)
        {
          redTeamPlayer.sendTitle(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Blue", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
          redTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
          redTeamPlayer.setGameMode(GameMode.SURVIVAL);
          redTeamPlayer.getInventory().clear();
          
          Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(redTeamPlayer.getUniqueId())) + 10);
          main.money.put(redTeamPlayer.getUniqueId(), addMoney.toString());
          redTeamPlayer.sendMessage("You have recieved 10 coins!");
        }
        for (Player bTeamPlayer : main.airBaseB)
        {
          bTeamPlayer.sendTitle(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Blue", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
          bTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
          bTeamPlayer.setGameMode(GameMode.SURVIVAL);
          bTeamPlayer.getInventory().clear();
          
          Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(bTeamPlayer.getUniqueId())) + 12);
          main.money.put(bTeamPlayer.getUniqueId(), addMoney.toString());
          bTeamPlayer.sendMessage("You have recieved 12 coins!");
        }
        StartCommand.mode = "NoMode";
        
        StartCommand.teamSize = "0";
        
        StartCommand.map = "NoMap";
        
        StartCommand.Blue.clear();
        StartCommand.Red.clear();
        
        Bukkit.getScheduler().runTaskLater(main, new Runnable()
        {
          public void run()
          {
            ArenaManager.pasteArena("ABSchematic1", "ABSchematic2", Bukkit.getServer().getWorld("Fire"), new Vector(-62, 76, 0), EventSystem.main);
            EventSystem.main.airBase.clear();
            EventSystem.main.airBaseB.clear();
            EventSystem.main.airBaseR.clear();
          }
        }, 20L);
      }
    }
    for (Player redTeamPlayer : main.airBaseB) {
      if (Bukkit.getWorld("Fire").getBlockAt(-62, 84, 34).getType().equals(Material.AIR))
      {
        StartCommand.infilState = GameState.RESETTING;
        for (Player rTeamPlayer : main.airBaseR)
        {
          rTeamPlayer.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
          rTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
          rTeamPlayer.setGameMode(GameMode.SURVIVAL);
          rTeamPlayer.getInventory().clear();
          
          Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(redTeamPlayer.getUniqueId())) + 12);
          main.money.put(redTeamPlayer.getUniqueId(), addMoney.toString());
          redTeamPlayer.sendMessage("You have recieved 12 coins!");
        }
        for (Player blueTeamPlayer : main.airBaseB)
        {
          blueTeamPlayer.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
          blueTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
          blueTeamPlayer.setGameMode(GameMode.SURVIVAL);
          blueTeamPlayer.getInventory().clear();
          
          Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(blueTeamPlayer.getUniqueId())) + 10);
          main.money.put(blueTeamPlayer.getUniqueId(), addMoney.toString());
          blueTeamPlayer.sendMessage("You have recieved 10 coins!");
        }
        StartCommand.mode = "NoMode";
        
        StartCommand.teamSize = "0";
        
        StartCommand.map = "NoMap";
        
        StartCommand.Blue.clear();
        StartCommand.Red.clear();
        
        Bukkit.getScheduler().runTaskLater(main, new Runnable()
        {
          public void run()
          {
            World w = null;
            if (Bukkit.getServer().getWorld("Fire") == null) {
              w = Bukkit.getServer().getWorld("world");
            } else {
              w = Bukkit.getServer().getWorld("Fire");
            }
            ArenaManager.pasteArena("ABSchematic1", "ABSchematic2", w, new Vector(-62, 76, 0), EventSystem.main);
            EventSystem.main.airBase.clear();
            EventSystem.main.airBaseB.clear();
            EventSystem.main.airBaseR.clear();
          }
        }, 20L);
      }
    }
  }
  
  @EventHandler
  public void onFakeDeath2(EntityDeathEvent e)
  {
    Entity entity = e.getEntity();
    if ((entity instanceof Player))
    {
      final Player player = (Player)entity;
      if ((StartCommand.state == GameState.INGAME) || (StartCommand.infilState == GameState.INGAME))
      {
        ((Cancellable)e).setCancelled(true);
        World w = null;
        if (Bukkit.getServer().getWorld("Fire") == null) {
          w = Bukkit.getServer().getWorld("world");
        } else {
          w = Bukkit.getServer().getWorld("Fire");
        }
        if (main.gameMode.containsKey(player))
        {
          if (((String)main.gameMode.get(player)).equals("Classic"))
          {
            for (Player aop : Bukkit.getOnlinePlayers()) {
              if (main.stoneFortress.contains(aop)) {
                aop.sendMessage(ChatColor.GRAY + player.getName() + " has just died!");
              }
            }
            player.sendTitle(ChatColor.RED + "You have just died!", "", 20, 40, 20);
            player.setHealth(20.0D);
            StartCommand.Spectator.add(player);
            player.setGameMode(GameMode.SPECTATOR);
            player.teleport(new Location(w, 0.0D, 76.0D, 0.0D));
            if (main.stoneFortress.contains(player))
            {
              if (main.stoneFortressB.contains(player)) {
                main.stoneFortressBDead.add(player);
              } else {
                main.stoneFortressRDead.add(player);
              }
              if (main.stoneFortressR.size() == main.stoneFortressRDead.size()) {
                ClassicWin(Integer.valueOf(1), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
              }
              if (main.stoneFortressB.size() == main.stoneFortressBDead.size()) {
                ClassicWin(Integer.valueOf(2), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
              }
            }
          }
          if (((String)main.gameMode.get(player)).equals("Infiltration"))
          {
            for (Player aop : Bukkit.getOnlinePlayers()) {
              if (main.airBase.contains(aop)) {
                aop.sendMessage(ChatColor.GRAY + player.getName() + " has just died!");
              }
            }
            player.setHealth(20.0D);
            player.setGameMode(GameMode.SPECTATOR);
            player.teleport(new Location(w, -62.0D, 76.0D, 0.0D));
            player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 3 seconds.", 10, 20, 0);
            Bukkit.getScheduler().runTaskLater(main, new Runnable()
            {
              public void run()
              {
                player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 2 seconds.", 0, 20, 0);
                Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                {
                  public void run()
                  {
                    player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 1 seconds.", 0, 20, 0);
                    Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                    {
                      public void run()
                      {
                        if (StartCommand.infilState == GameState.INGAME)
                        {
                          if (EventSystem.main.airBaseB.contains(player)) {
                            player.teleport(StartCommand.BlueAirBase);
                            player.setGameMode(GameMode.SURVIVAL);
                            player.getInventory().clear();
                            player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                          }
                          else if (EventSystem.main.airBaseR.contains(player))
                          {
                            player.teleport(StartCommand.RedAirBase);
                            player.setGameMode(GameMode.SURVIVAL);
                            player.getInventory().clear();
                            player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                          }
                        }
                        else {
                          player.teleport(Bukkit.getServer().getWorld("world").getSpawnLocation());
                        }
                      }
                    }, 20L);
                  }
                }, 20L);
              }
            }, 20L);
          }
        }
      }
    }
  }
  
  @EventHandler
  public void onFakeDeath(EntityDamageEvent e)
  {
    Entity entity = e.getEntity();
    if ((entity instanceof Player))
    {
      final Player player = (Player)entity;
      if (((StartCommand.state == GameState.INGAME) || (StartCommand.infilState == GameState.INGAME)) && 
        (player.getHealth() - e.getDamage() <= 0.0D))
      {
        e.setCancelled(true);
        World w = null;
        if (Bukkit.getServer().getWorld("Fire") == null) {
          w = Bukkit.getServer().getWorld("world");
        } else {
          w = Bukkit.getServer().getWorld("Fire");
        }
        if (main.gameMode.containsKey(player))
        {
          if (((String)main.gameMode.get(player)).equals("Classic"))
          {
            player.sendTitle(ChatColor.RED + "You have just died!", "", 20, 40, 20);
            for (Player aop : Bukkit.getOnlinePlayers()) {
              if (main.stoneFortress.contains(aop)) {
                aop.sendMessage(ChatColor.GRAY + player.getName() + " has just died!");
              }
            }
            player.setHealth(20.0D);
            StartCommand.Spectator.add(player);
            player.setGameMode(GameMode.SPECTATOR);
            player.teleport(new Location(w, 0.0D, 76.0D, 0.0D));
            if (main.stoneFortress.contains(player))
            {
              if (main.stoneFortressB.contains(player)) {
                main.stoneFortressBDead.add(player);
              } else {
                main.stoneFortressRDead.add(player);
              }
              if (main.stoneFortressR.size() == main.stoneFortressRDead.size()) {
                ClassicWin(Integer.valueOf(1), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
              }
              if (main.stoneFortressB.size() == main.stoneFortressBDead.size()) {
                ClassicWin(Integer.valueOf(2), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
              }
            }
          }
          if (((String)main.gameMode.get(player)).equals("Infiltration"))
          {
            for (Player aop : Bukkit.getOnlinePlayers()) {
              if (main.airBase.contains(aop)) {
                aop.sendMessage(ChatColor.GRAY + player.getName() + " has just died!");
              }
            }
            player.setHealth(20.0D);
            player.setGameMode(GameMode.SPECTATOR);
            player.teleport(new Location(w, -62.0D, 76.0D, 0.0D));
            player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 3 seconds.", 10, 20, 0);
            Bukkit.getScheduler().runTaskLater(main, new Runnable()
            {
              public void run()
              {
                player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 2 seconds.", 0, 20, 0);
                Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                {
                  public void run()
                  {
                    player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 1 seconds.", 0, 20, 0);
                    Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                    {
                      public void run()
                      {
                        if (StartCommand.infilState == GameState.INGAME)
                        {
                          if (EventSystem.main.airBaseB.contains(player))
                          {
                            player.teleport(StartCommand.BlueAirBase);
                            player.setGameMode(GameMode.SURVIVAL);
                            player.getInventory().clear();
                            player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                          }
                          else if (EventSystem.main.airBaseR.contains(player))
                          {
                            player.teleport(StartCommand.RedAirBase);
                            player.setGameMode(GameMode.SURVIVAL);
                            player.getInventory().clear();
                            player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                          }
                        }
                        else {
                          player.teleport(Bukkit.getServer().getWorld("world").getSpawnLocation());
                        }
                      }
                    }, 20L);
                  }
                }, 20L);
              }
            }, 20L);
          }
        }
      }
    }
  }
  
  @EventHandler
  public void eggExplode(PlayerEggThrowEvent e)
  {
    if ((e.getEgg().getWorld().equals(Bukkit.getWorld("Fire"))) && ((StartCommand.state.equals(GameState.INGAME)) || (StartCommand.infilState == GameState.INGAME)))
    {
      Random rand = new Random();
      int rng = rand.nextInt(5);
      switch (rng)
      {
      case 1: 
        e.getPlayer().getWorld().createExplosion(e.getEgg().getLocation(), 1.0F);
        break;
      case 2: 
        e.getPlayer().getWorld().createExplosion(e.getEgg().getLocation(), 1.0F);
        break;
      case 3: 
        e.getPlayer().getWorld().createExplosion(e.getEgg().getLocation(), 2.0F);
        break;
      case 4: 
        e.getPlayer().getWorld().createExplosion(e.getEgg().getLocation(), 1.0F);
        break;
      case 5: 
        e.getPlayer().getWorld().createExplosion(e.getEgg().getLocation(), 1.0F);
      }
    }
  }
  
  @EventHandler
  public void Chat(AsyncPlayerChatEvent e)
  {
    Player player = e.getPlayer();
    String playerMessage = e.getMessage();
    for (Player aop : Bukkit.getOnlinePlayers())
    {
      e.setCancelled(true);
      aop.sendMessage(ChatColor.AQUA + player.getName() + ChatColor.WHITE + ": " + playerMessage);
    }
  }
  
  @EventHandler
  public void gameJoin(PlayerJoinEvent e)
  {
    Player player = e.getPlayer();
    if (main.getDataBase().contains(player.getUniqueId().toString()))
    {
      main.money.put(player.getUniqueId(), main.getDataBase().getString(player.getUniqueId().toString() + ".Money"));
      main.getDataBase().set(player.getUniqueId().toString() + ".IGN", player.getName());
    }
    else
    {
      main.getDataBase().createSection(player.getUniqueId().toString());
      main.getDataBase().set(player.getUniqueId().toString() + ".IGN", player.getName());
      main.getDataBase().set(player.getUniqueId().toString() + ".Money", "0");
      main.money.put(player.getUniqueId(), "0");
    }
    try
    {
      main.getDataBase().save(main.getFile());
    }
    catch (IOException e1)
    {
      e1.printStackTrace();
    }
    if (main.offlineLeavePlayer.contains(player))
    {
      main.offlineLeavePlayer.remove(player);
      player.teleport(Bukkit.getWorld("world").getSpawnLocation());
      player.getInventory().clear();
      player.setHealth(20.0D);
    }
  }
  
  @EventHandler
  public void gameLeave(PlayerQuitEvent e)
  {
    Player player = e.getPlayer();
    if (main.money.containsKey(player.getUniqueId())) {
      main.getDataBase().set(player.getUniqueId().toString() + ".Money", main.money.get(player.getUniqueId()));
    }
    if (main.stoneFortress.contains(player))
    {
      main.offlineLeavePlayer.add(player);
      if (StartCommand.state.equals(GameState.INGAME))
      {
        if (main.stoneFortress.contains(player))
        {
          if (main.stoneFortressB.contains(player)) {
            main.stoneFortressBDead.add(player);
          } else {
            main.stoneFortressRDead.add(player);
          }
          for (Player aop : Bukkit.getOnlinePlayers()) {
            if (main.stoneFortress.contains(aop)) {
              aop.sendMessage(player.getName() + " has forfeited!");
            }
          }
          if (main.stoneFortressR.size() == main.stoneFortressRDead.size()) {
            ClassicWin(Integer.valueOf(1), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
          }
          if (main.stoneFortressB.size() == main.stoneFortressBDead.size()) {
            ClassicWin(Integer.valueOf(2), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
          }
          main.gameMode.remove(player);
          main.stoneFortress.remove(player);
        }
      }
      else {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if (main.stoneFortress.contains(aop))
          {
            main.gameMode.remove(player);
            main.stoneFortress.remove(player);
            aop.sendMessage(player.getName() + " has left the match (" + main.stoneFortress.size() + "/" + Integer.parseInt(StartCommand.teamSize) * 2 + ")!");
            if (main.stoneFortressB.contains(player)) {
              main.stoneFortressB.remove(player);
            }
            if (main.stoneFortressR.contains(player)) {
              main.stoneFortressB.remove(player);
            }
          }
        }
      }
    }
    if (main.airBase.contains(player))
    {
      player.teleport(Bukkit.getWorld("world").getSpawnLocation());
      if (StartCommand.infilState.equals(GameState.INGAME))
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          aop.sendMessage(player.getName() + " has fortfeited!");
        }
        if (main.airBaseB.contains(player)) {
          player.getWorld().getBlockAt(-62, 84, -34).breakNaturally();
        }
        if (main.airBaseB.contains(player)) {
          player.getWorld().getBlockAt(-62, 84, 34).breakNaturally();
        }
        main.gameMode.remove(player);
        main.airBase.remove(player);
      }
      else
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if (main.airBase.contains(aop))
          {
            main.gameMode.remove(player);
            main.airBase.remove(player);
            aop.sendMessage(player.getName() + " has left the match (" + main.airBase.size() + "/" + Integer.parseInt(StartCommand.infilTeamSize) * 2 + ")!");
            if (main.airBaseB.contains(player)) {
              main.airBaseB.remove(player);
            }
            if (main.airBaseR.contains(player)) {
              main.airBaseB.remove(player);
            }
          }
        }
      }
    }
  }
  
  @EventHandler
  public void teamGUIClick(InventoryClickEvent e)
  {
    Player player = (Player)e.getWhoClicked();
    if ((ChatColor.translateAlternateColorCodes('&', e.getClickedInventory().getTitle()).equals(ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "Choose Your Team")) && 
      (e.getCurrentItem() != null))
    {
      e.setCancelled(true);
      
      ItemStack currentItem = e.getCurrentItem();
      if (e.getCurrentItem().getType() == Material.STAINED_GLASS_PANE)
      {
        if (currentItem.getDurability() == 11)
        {
          if (main.stoneFortress.contains(player)) {
            if (main.stoneFortressB.size() == Integer.parseInt(StartCommand.teamSize))
            {
              player.sendMessage("That team is full!");
            }
            else if (main.stoneFortress.contains(player))
            {
              player.sendMessage(ChatColor.BLUE + "You have joined the blue team!");
              main.stoneFortressB.add(player);
              player.closeInventory();
            }
          }
          if (main.airBase.contains(player)) {
            if (main.airBaseB.size() == Integer.parseInt(StartCommand.teamSize))
            {
              player.sendMessage("That team is full!");
            }
            else if (main.airBase.contains(player))
            {
              player.sendMessage(ChatColor.BLUE + "You have joined the blue team!");
              main.airBaseB.add(player);
              player.closeInventory();
            }
          }
        }
        else if (currentItem.getDurability() == 14)
        {
          if (main.stoneFortress.contains(player)) {
            if (main.stoneFortressR.size() == Integer.parseInt(StartCommand.teamSize))
            {
              player.sendMessage("That team is full!");
            }
            else if (main.stoneFortress.contains(player))
            {
              player.sendMessage(ChatColor.RED + "You have joined the red team!");
              main.stoneFortressR.add(player);
              player.closeInventory();
            }
          }
          if (main.airBase.contains(player)) {
            if (main.airBaseR.size() == Integer.parseInt(StartCommand.teamSize))
            {
              player.sendMessage("That team is full!");
            }
            else if (main.airBase.contains(player))
            {
              player.sendMessage(ChatColor.RED + "You have joined the red team!");
              main.airBaseR.add(player);
              player.closeInventory();
            }
          }
        }
      }
      else {
        e.setCancelled(true);
      }
    }
    if ((ChatColor.translateAlternateColorCodes('&', e.getClickedInventory().getTitle()).equals(ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "Fireball Gamemodes")) && 
      (e.getCurrentItem() != null))
    {
      e.setCancelled(true);
      
      ItemStack currentItem = e.getCurrentItem();
      switch (e.getCurrentItem().getType())
      {
      case SMOOTH_STAIRS: 
        if (currentItem.getType().equals(Material.FIREBALL))
        {
          player.closeInventory();
          player.openInventory(StartCommand.classicMapsGUI);
          player.sendMessage("You have chosen Classic mode.");
          main.gameMode.put(player, "Classic");
          StartCommand.teamSize = StartCommand.rawTeamSize;
        }
      case SULPHUR: 
        if (currentItem.getType().equals(Material.BANNER))
        {
          player.closeInventory();
          player.openInventory(StartCommand.infiltrationMapsGUI);
          player.sendMessage("You have chosen Infiltration mode.");
          main.gameMode.put(player, "Infiltration");
          StartCommand.infilTeamSize = StartCommand.rawTeamSize;
        }
      case LINGERING_POTION: 
        if (currentItem.getType().equals(Material.IRON_PICKAXE)) {
          if (player.isOp())
          {
            player.closeInventory();
            player.openInventory(StartCommand.constructionMapsGUI);
            player.sendMessage("You have chosen Construction mode.");
            main.gameMode.put(player, "Construction");
          }
          else
          {
            player.sendMessage("Coming soon!");
          }
        }
        break;
      }
    }
    ItemStack baseRepair;
    if ((ChatColor.translateAlternateColorCodes('&', e.getClickedInventory().getTitle()).equals(ChatColor.GOLD + "" + ChatColor.BOLD + "Shop")) && 
      (e.getCurrentItem() != null))
    {
      e.setCancelled(true);
      
      ItemStack currentItem = e.getCurrentItem();
      switch (e.getCurrentItem().getType())
      {
      case SANDSTONE_STAIRS: 
        if (currentItem.getType().equals(Material.BLAZE_ROD))
        {
          player.sendMessage("You have recieved a Flamethrower!");
          ItemStack flameThrower = new ItemStack(Material.BLAZE_ROD, 1);
          ItemMeta flameThrowerMeta = flameThrower.getItemMeta();
          flameThrowerMeta.setDisplayName(ChatColor.RED + "Flamethrower");
          flameThrowerMeta.addEnchant(Enchantment.FIRE_ASPECT, 1, true);
          flameThrower.setItemMeta(flameThrowerMeta);
          player.getInventory().addItem(new ItemStack[] { flameThrower });
        }
        break;
      case RECORD_7: 
        if (currentItem.getType().equals(Material.EGG))
        {
          player.sendMessage("You have recieved a Explosive Egg!");
          ItemStack explosiveEgg = new ItemStack(Material.EGG, 1);
          ItemMeta explosiveEggMeta = explosiveEgg.getItemMeta();
          explosiveEggMeta.setDisplayName(ChatColor.YELLOW + "Explosive Egg");
          explosiveEgg.setItemMeta(explosiveEggMeta);
          player.getInventory().addItem(new ItemStack[] { explosiveEgg });
        }
        break;
      case LINGERING_POTION: 
        if (currentItem.getType().equals(Material.IRON_PICKAXE))
        {
          player.sendMessage("You have recieved a Base Repair!");
          baseRepair = new ItemStack(Material.IRON_PICKAXE, 1);
          ItemMeta baseRepairMeta = baseRepair.getItemMeta();
          baseRepairMeta.setDisplayName(ChatColor.GREEN + "Base Repair");
          baseRepairMeta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, true);
          baseRepair.setItemMeta(baseRepairMeta);
          player.getInventory().addItem(new ItemStack[] { baseRepair });
        }
        break;
      }
    }
    if ((ChatColor.translateAlternateColorCodes('&', e.getClickedInventory().getTitle()).equals(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Classic Maps")) && 
      (e.getCurrentItem() != null))
    {
      e.setCancelled(true);
      if (e.getCurrentItem().getType().equals(Material.SMOOTH_BRICK))
      {
        player.closeInventory();
        
        player.sendMessage("You have chosen the map Stone Fortress.");
        main.stoneFortress.add(player);
        for (final Player aop : Bukkit.getOnlinePlayers()) {
          if (main.stoneFortress.contains(aop))
          {
            aop.sendMessage(ChatColor.GOLD + player.getName() + " has joined the match (" + main.stoneFortress.size() + "/" + Integer.parseInt(StartCommand.teamSize) * 2 + ")!");
            if (main.stoneFortress.size() == Integer.parseInt(StartCommand.teamSize) * 2)
            {
              aop.sendMessage("Game starting...");
              StartCommand.state = GameState.INGAME;
              Bukkit.getScheduler().runTaskLater(main, new Runnable()
              {
                public void run()
                {
                  aop.openInventory(StartCommand.chooseTeamGUI);
                  Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                  {
                    public void run()
                    {
                      aop.sendMessage("Choose your teams quickly or you will be randomly placed in teams!");
                      Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                      {
                        public void run()
                        {
                          if (EventSystem.main.stoneFortress.size() == Integer.parseInt(StartCommand.teamSize) * 2)
                          {
                            if (EventSystem.main.stoneFortressB.size() + EventSystem.main.stoneFortressR.size() == Integer.parseInt(StartCommand.teamSize) * 2)
                            {
                              aop.sendMessage("Game start!");
                              aop.sendMessage(ChatColor.RED + "Goal: " + ChatColor.WHITE + "Kill the other team.");
                              if (EventSystem.main.stoneFortressB.contains(aop))
                              {
                                aop.teleport(StartCommand.BlueStoneFortress);
                                aop.getInventory().clear();
                                aop.setHealth(20.0D);
                                aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                              }
                              if (EventSystem.main.stoneFortressR.contains(aop))
                              {
                                aop.teleport(StartCommand.RedStoneFortress);
                                aop.getInventory().clear();
                                aop.setHealth(20.0D);
                                aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                              }
                            }
                            else
                            {
                              if (EventSystem.main.stoneFortressB.size() != Integer.parseInt(StartCommand.teamSize))
                              {
                                aop.sendMessage(ChatColor.RED + "Goal: " + ChatColor.WHITE + "Kill the other team.");
                                if ((EventSystem.main.stoneFortressB.contains(aop)) || (EventSystem.main.stoneFortressR.contains(aop)))
                                {
                                  if (EventSystem.main.stoneFortressR.contains(aop))
                                  {
                                    if (EventSystem.main.airBaseR.contains(aop))
                                    {
                                      aop.teleport(StartCommand.RedStoneFortress);
                                      aop.getInventory().clear();
                                      aop.setHealth(20.0D);
                                      aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                    }
                                    if (EventSystem.main.stoneFortressB.contains(aop))
                                    {
                                      aop.teleport(StartCommand.BlueStoneFortress);
                                      aop.getInventory().clear();
                                      aop.setHealth(20.0D);
                                      aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                    }
                                  }
                                }
                                else
                                {
                                  EventSystem.main.stoneFortressB.add(aop);
                                  aop.teleport(StartCommand.BlueStoneFortress);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                }
                              }
                              if (EventSystem.main.stoneFortressR.size() != Integer.parseInt(StartCommand.teamSize)) {
                                if ((EventSystem.main.stoneFortressR.contains(aop)) || (EventSystem.main.stoneFortressB.contains(aop)))
                                {
                                  if (EventSystem.main.stoneFortressB.contains(aop))
                                  {
                                    if (EventSystem.main.stoneFortressR.contains(aop))
                                    {
                                      aop.teleport(StartCommand.RedStoneFortress);
                                      aop.getInventory().clear();
                                      aop.setHealth(20.0D);
                                      aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                    }
                                    if (EventSystem.main.stoneFortressB.contains(aop))
                                    {
                                      aop.teleport(StartCommand.BlueStoneFortress);
                                      aop.getInventory().clear();
                                      aop.setHealth(20.0D);
                                      aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                    }
                                  }
                                }
                                else
                                {
                                  EventSystem.main.stoneFortressR.add(aop);
                                  aop.teleport(StartCommand.RedStoneFortress);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                }
                              }
                            }
                          }
                          else
                          {
                            aop.sendMessage("Game cancelled, not enough players!");
                            StartCommand.state = GameState.READY;
                          }
                        }
                      }, 40L);
                    }
                  }, 120L);
                }
              }, 20L);
            }
          }
        }
      }
    }
    if ((ChatColor.translateAlternateColorCodes('&', e.getClickedInventory().getTitle()).equals(ChatColor.GOLD + "" + ChatColor.BOLD + "Construction Maps")) && 
      (e.getCurrentItem() != null))
    {
      e.setCancelled(true);
      if (e.getCurrentItem().getType().equals(Material.IRON_PICKAXE))
      {
        player.closeInventory();
        
        player.sendMessage("You have chosen the map Stone Fortress.");
        main.skyIsland.add(player);
        for (final Player aop : Bukkit.getOnlinePlayers()) {
          if (main.skyIsland.contains(aop))
          {
            aop.sendMessage(ChatColor.GOLD + player.getName() + " has joined the match (" + main.skyIsland.size() + "/" + Integer.parseInt(StartCommand.constructionTeamSize) * 2 + ")!");
            if (main.skyIsland.size() == Integer.parseInt(StartCommand.constructionTeamSize) * 2)
            {
              aop.sendMessage("Game starting...");
              StartCommand.state = GameState.INGAME;
              Bukkit.getScheduler().runTaskLater(main, new Runnable()
              {
                public void run()
                {
                  aop.openInventory(StartCommand.chooseTeamGUI);
                  Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                  {
                    public void run()
                    {
                      aop.sendMessage("Choose your teams quickly or you will be randomly placed in teams!");
                      Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                      {
                        public void run()
                        {
                          if (EventSystem.main.skyIsland.size() == Integer.parseInt(StartCommand.constructionTeamSize) * 2)
                          {
                            LivingEntity blueKing = (LivingEntity)Bukkit.getWorld("world").spawnEntity(StartCommand.BlueSkyIsland, EntityType.ZOMBIE);
                            blueKing.setCustomName(ChatColor.DARK_BLUE + "The Blue King");
                            blueKing.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, -1, 255));
                            
                            LivingEntity redKing = (LivingEntity)Bukkit.getWorld("world").spawnEntity(StartCommand.RedSkyIsland, EntityType.ZOMBIE);
                            redKing.setCustomName(ChatColor.DARK_RED + "The Red King");
                            redKing.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, -1, 255));
                            if (EventSystem.main.skyIslandB.size() + EventSystem.main.skyIslandR.size() == Integer.parseInt(StartCommand.constructionTeamSize) * 2)
                            {
                              aop.sendMessage("Game start!");
                              aop.sendMessage(ChatColor.RED + "Goal: " + ChatColor.WHITE + "Defend your king, kill the other team's king.");
                              if (EventSystem.main.skyIslandB.contains(aop))
                              {
                                aop.teleport(StartCommand.BlueSkyIsland);
                                aop.getInventory().clear();
                                aop.setHealth(20.0D);
                                aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.WOOD_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.WOOD_PICKAXE, 1), new ItemStack(Material.ARROW, 16), new ItemStack(Material.BREAD, 64), new ItemStack(Material.LEATHER_HELMET, 1), new ItemStack(Material.LEATHER_CHESTPLATE, 1), new ItemStack(Material.LEATHER_LEGGINGS, 1), new ItemStack(Material.LEATHER_BOOTS, 1) });
                              }
                              if (EventSystem.main.skyIslandR.contains(aop))
                              {
                                aop.teleport(StartCommand.RedSkyIsland);
                                aop.getInventory().clear();
                                aop.setHealth(20.0D);
                                aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.WOOD_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.WOOD_PICKAXE, 1), new ItemStack(Material.ARROW, 16), new ItemStack(Material.BREAD, 64), new ItemStack(Material.LEATHER_HELMET, 1), new ItemStack(Material.LEATHER_CHESTPLATE, 1), new ItemStack(Material.LEATHER_LEGGINGS, 1), new ItemStack(Material.LEATHER_BOOTS, 1) });
                              }
                            }
                            else
                            {
                              if (EventSystem.main.skyIslandB.size() != Integer.parseInt(StartCommand.constructionTeamSize))
                              {
                                aop.sendMessage(ChatColor.RED + "Goal: " + ChatColor.WHITE + "Kill the other team.");
                                if ((EventSystem.main.skyIslandB.contains(aop)) || (EventSystem.main.skyIslandR.contains(aop)))
                                {
                                  if (EventSystem.main.skyIslandR.contains(aop))
                                  {
                                    aop.teleport(StartCommand.RedSkyIsland);
                                    aop.getInventory().clear();
                                    aop.setHealth(20.0D);
                                    aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.WOOD_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.WOOD_PICKAXE, 1), new ItemStack(Material.ARROW, 16), new ItemStack(Material.BREAD, 64), new ItemStack(Material.LEATHER_HELMET, 1), new ItemStack(Material.LEATHER_CHESTPLATE, 1), new ItemStack(Material.LEATHER_LEGGINGS, 1), new ItemStack(Material.LEATHER_BOOTS, 1) });
                                  }
                                }
                                else
                                {
                                  EventSystem.main.skyIslandB.add(aop);
                                  aop.teleport(StartCommand.BlueSkyIsland);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.WOOD_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.WOOD_PICKAXE, 1), new ItemStack(Material.ARROW, 16), new ItemStack(Material.BREAD, 64), new ItemStack(Material.LEATHER_HELMET, 1), new ItemStack(Material.LEATHER_CHESTPLATE, 1), new ItemStack(Material.LEATHER_LEGGINGS, 1), new ItemStack(Material.LEATHER_BOOTS, 1) });
                                }
                              }
                              if (EventSystem.main.skyIslandR.size() != Integer.parseInt(StartCommand.constructionTeamSize)) {
                                if ((EventSystem.main.skyIslandR.contains(aop)) || (EventSystem.main.skyIslandB.contains(aop)))
                                {
                                  if (EventSystem.main.skyIslandB.contains(aop))
                                  {
                                    EventSystem.main.skyIslandB.add(aop);
                                    aop.teleport(StartCommand.BlueSkyIsland);
                                    aop.getInventory().clear();
                                    aop.setHealth(20.0D);
                                    aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.WOOD_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.WOOD_PICKAXE, 1), new ItemStack(Material.ARROW, 16), new ItemStack(Material.BREAD, 64), new ItemStack(Material.LEATHER_HELMET, 1), new ItemStack(Material.LEATHER_CHESTPLATE, 1), new ItemStack(Material.LEATHER_LEGGINGS, 1), new ItemStack(Material.LEATHER_BOOTS, 1) });
                                  }
                                }
                                else
                                {
                                  EventSystem.main.skyIslandR.add(aop);
                                  aop.teleport(StartCommand.RedSkyIsland);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.WOOD_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.WOOD_PICKAXE, 1), new ItemStack(Material.ARROW, 16), new ItemStack(Material.BREAD, 64), new ItemStack(Material.LEATHER_HELMET, 1), new ItemStack(Material.LEATHER_CHESTPLATE, 1), new ItemStack(Material.LEATHER_LEGGINGS, 1), new ItemStack(Material.LEATHER_BOOTS, 1) });
                                }
                              }
                            }
                          }
                          else
                          {
                            aop.sendMessage("Game cancelled, not enough players!");
                            StartCommand.state = GameState.READY;
                          }
                        }
                      }, 40L);
                    }
                  }, 120L);
                }
              }, 20L);
            }
          }
        }
      }
    }
    if (ChatColor.translateAlternateColorCodes('&', e.getClickedInventory().getTitle()).equals(ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "Infiltration Maps"))
    {
      player.closeInventory();
      
      player.sendMessage("You have chosen the map Airbase.");
      main.airBase.add(player);
      for (final Player aop : Bukkit.getOnlinePlayers()) {
        if (main.airBase.contains(aop))
        {
          aop.sendMessage(ChatColor.GOLD + player.getName() + " has joined the match (" + main.airBase.size() + "/" + Integer.parseInt(StartCommand.infilTeamSize) * 2 + ")!");
          if (main.airBase.size() == Integer.parseInt(StartCommand.infilTeamSize) * 2)
          {
            aop.sendMessage("Game starting...");
            StartCommand.infilState = GameState.INGAME;
            Bukkit.getScheduler().runTaskLater(main, new Runnable()
            {
              public void run()
              {
                aop.openInventory(StartCommand.chooseTeamGUI);
                Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                {
                  public void run()
                  {
                    aop.sendMessage("Choose your teams quickly or you will be randomly placed in teams!");
                    Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                    {
                      public void run()
                      {
                        if (EventSystem.main.airBase.size() == Integer.parseInt(StartCommand.infilTeamSize) * 2)
                        {
                          if (EventSystem.main.airBaseB.size() + EventSystem.main.airBaseR.size() == Integer.parseInt(StartCommand.infilTeamSize) * 2)
                          {
                            aop.sendMessage("Game start!");
                            aop.sendMessage(ChatColor.RED + "Goal: " + ChatColor.WHITE + "Retrieve your flag from the other team.");
                            if (EventSystem.main.airBaseB.contains(aop))
                            {
                              aop.teleport(StartCommand.BlueAirBase);
                              aop.getInventory().clear();
                              aop.setHealth(20.0D);
                              aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                            }
                            if (EventSystem.main.airBaseR.contains(aop))
                            {
                              aop.teleport(StartCommand.RedAirBase);
                              aop.getInventory().clear();
                              aop.setHealth(20.0D);
                              aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                            }
                          }
                          else
                          {
                            if (EventSystem.main.airBaseB.size() != Integer.parseInt(StartCommand.infilTeamSize))
                            {
                              aop.sendMessage(ChatColor.RED + "Goal: " + ChatColor.WHITE + "Retrieve your flag from the other team.");
                              if ((EventSystem.main.airBaseB.contains(aop)) || (EventSystem.main.airBaseR.contains(aop)))
                              {
                                if (EventSystem.main.airBaseR.contains(aop))
                                {
                                  aop.teleport(StartCommand.RedAirBase);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                }
                                if (EventSystem.main.airBaseB.contains(aop))
                                {
                                  aop.teleport(StartCommand.BlueAirBase);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                }
                              }
                              else
                              {
                                EventSystem.main.airBaseB.add(aop);
                                aop.teleport(StartCommand.BlueAirBase);
                                aop.getInventory().clear();
                                aop.setHealth(20.0D);
                                aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                              }
                            }
                            if (EventSystem.main.airBaseR.size() != Integer.parseInt(StartCommand.infilTeamSize)) {
                              if ((EventSystem.main.airBaseR.contains(aop)) || (EventSystem.main.airBaseB.contains(aop)))
                              {
                                if (EventSystem.main.airBaseR.contains(aop))
                                {
                                  aop.teleport(StartCommand.RedAirBase);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                }
                                if (EventSystem.main.airBaseB.contains(aop))
                                {
                                  aop.teleport(StartCommand.BlueAirBase);
                                  aop.getInventory().clear();
                                  aop.setHealth(20.0D);
                                  aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                                }
                              }
                              else
                              {
                                EventSystem.main.airBaseR.add(aop);
                                aop.teleport(StartCommand.RedAirBase);
                                aop.getInventory().clear();
                                aop.setHealth(20.0D);
                                aop.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192,(short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                              }
                            }
                          }
                        }
                        else
                        {
                          aop.sendMessage("Game cancelled, not enough players!");
                          StartCommand.infilState = GameState.READY;
                        }
                      }
                    }, 40L);
                  }
                }, 120L);
              }
            }, 20L);
          }
        }
      }
    }
  }
  
  public static void ClassicWin(Integer team, ArrayList<Player> blue, ArrayList<Player> red, String map, Vector location, World w, Main m)
  {
    StartCommand.state = GameState.RESETTING;
    switch (team.intValue())
    {
    case 1: 
      for (Player rTeamPlayer : red)
      {
        rTeamPlayer.sendTitle(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Blue", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
        rTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
        rTeamPlayer.setGameMode(GameMode.SURVIVAL);
        rTeamPlayer.getInventory().clear();
        
        Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(rTeamPlayer.getUniqueId())) + 10);
        main.money.put(rTeamPlayer.getUniqueId(), addMoney.toString());
        rTeamPlayer.sendMessage("You have recieved 10 coins!");
        
        main.gameMode.remove(rTeamPlayer);
      }
      for (Player bTeamPlayer : blue)
      {
        bTeamPlayer.sendTitle(ChatColor.DARK_BLUE + "" + ChatColor.BOLD + "Blue", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
        bTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
        bTeamPlayer.setGameMode(GameMode.SURVIVAL);
        bTeamPlayer.getInventory().clear();
        
        Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(bTeamPlayer.getUniqueId())) + 12);
        main.money.put(bTeamPlayer.getUniqueId(), addMoney.toString());
        bTeamPlayer.sendMessage("You have recieved 12 coins!");
        
        main.gameMode.remove(bTeamPlayer);
      }
      ArenaManager.pasteArena(map + "Schematic1", map + "Schematic2", w, location, m);
      main.stoneFortress.clear();
      main.stoneFortressB.clear();
      main.stoneFortressR.clear();
      main.stoneFortressBDead.clear();
      main.stoneFortressRDead.clear();
    case 2: 
      for (Player rTeamPlayer : red)
      {
        rTeamPlayer.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
        rTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
        rTeamPlayer.setGameMode(GameMode.SURVIVAL);
        rTeamPlayer.getInventory().clear();
        
        Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(rTeamPlayer.getUniqueId())) + 12);
        main.money.put(rTeamPlayer.getUniqueId(), addMoney.toString());
        rTeamPlayer.sendMessage("You have recieved 12 coins!");
        
        main.gameMode.remove(rTeamPlayer);
      }
      for (Player bTeamPlayer : blue)
      {
        bTeamPlayer.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
        bTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
        bTeamPlayer.setGameMode(GameMode.SURVIVAL);
        bTeamPlayer.getInventory().clear();
        
        Integer addMoney = Integer.valueOf(Integer.parseInt((String)main.money.get(bTeamPlayer.getUniqueId())) + 10);
        main.money.put(bTeamPlayer.getUniqueId(), addMoney.toString());
        bTeamPlayer.sendMessage("You have recieved 10 coins!");
        
        main.gameMode.remove(bTeamPlayer);
      }
      ArenaManager.pasteArena(map + "Schematic1", map + "Schematic2", w, location, m);
      main.stoneFortress.clear();
      main.stoneFortressB.clear();
      main.stoneFortressR.clear();
      main.stoneFortressBDead.clear();
      main.stoneFortressRDead.clear();
    }
  }
  
  @EventHandler
  public void gameEvents(PlayerMoveEvent e)
  {
    if ((StartCommand.state == GameState.INGAME) || (StartCommand.infilState == GameState.INGAME))
    {
      ItemStack[] arrayOfItemStack;
      int j = (arrayOfItemStack = e.getPlayer().getInventory().getContents()).length;
      for (int i = 0; i < j; i++)
      {
        ItemStack item = arrayOfItemStack[i];
        if ((e.getPlayer().getInventory().getHelmet() == null) && (item.getType().toString().toLowerCase().contains("helmet")))
        {
          e.getPlayer().getInventory().setHelmet(item);
          e.getPlayer().getInventory().remove(item);
        }
        if ((e.getPlayer().getInventory().getChestplate() == null) && (item.getType().toString().toLowerCase().contains("chestplate")))
        {
          e.getPlayer().getInventory().setChestplate(item);
          e.getPlayer().getInventory().remove(item);
        }
        if ((e.getPlayer().getInventory().getLeggings() == null) && (item.getType().toString().toLowerCase().contains("leggings")))
        {
          e.getPlayer().getInventory().setLeggings(item);
          e.getPlayer().getInventory().remove(item);
        }
        if ((e.getPlayer().getInventory().getBoots() == null) && (item.getType().toString().toLowerCase().contains("boots")))
        {
          e.getPlayer().getInventory().setBoots(item);
          e.getPlayer().getInventory().remove(item);
        }
      }
      InfiltrationWin();
    }
  }
  
  @EventHandler
  public void fallCheck(PlayerMoveEvent e)
  {
    final Player player = e.getPlayer();
    if (((StartCommand.state == GameState.INGAME) || (StartCommand.infilState == GameState.INGAME)) && 
      (player.getLocation().getY() >= 55.0D) && (player.getLocation().getY() <= 65.0D))
    {
      if ((main.gameMode.containsKey(player)) && 
        (((String)main.gameMode.get(player)).equals("Classic")))
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if (main.stoneFortress.contains(aop)) {
            aop.sendMessage(ChatColor.GRAY + player.getName() + " has just died!");
          }
        }
        player.sendTitle(ChatColor.RED + "You have just died!", "", 20, 40, 20);
        player.setHealth(20.0D);
        StartCommand.Spectator.add(player);
        player.setGameMode(GameMode.SPECTATOR);
        player.teleport(player.getLocation().add(0.0D, 20.0D, 0.0D));
        if (main.stoneFortress.contains(player))
        {
          if (main.stoneFortressB.contains(player)) {
            main.stoneFortressBDead.add(player);
          } else {
            main.stoneFortressRDead.add(player);
          }
          if (main.stoneFortressR.size() == main.stoneFortressRDead.size()) {
            ClassicWin(Integer.valueOf(1), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
          }
          if (main.stoneFortressB.size() == main.stoneFortressBDead.size()) {
            ClassicWin(Integer.valueOf(2), main.stoneFortressB, main.stoneFortressR, "SF", new Vector(0, 76, 0), Bukkit.getServer().getWorld("Fire"), main);
          }
        }
      }
      if (((String)main.gameMode.get(player)).equals("Infiltration"))
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if (main.airBase.contains(aop)) {
            aop.sendMessage(ChatColor.GRAY + player.getName() + " has just died!");
          }
        }
        player.setHealth(20.0D);
        player.setGameMode(GameMode.SPECTATOR);
        player.teleport(new Location(player.getWorld(), -62.0D, 76.0D, 0.0D));
        player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 3 seconds.", 10, 20, 0);
        Bukkit.getScheduler().runTaskLater(main, new Runnable()
        {
          public void run()
          {
            player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 2 seconds.", 0, 20, 0);
            Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
            {
              public void run()
              {
                player.sendTitle(ChatColor.RED + "You have just died!", ChatColor.WHITE + "Respawning in 1 seconds.", 0, 20, 0);
                Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                {
                  public void run()
                  {
                    if (StartCommand.infilState == GameState.INGAME)
                    {
                      if (EventSystem.main.airBaseB.contains(player))
                      {
                        player.teleport(StartCommand.BlueAirBase);
                        player.setGameMode(GameMode.SURVIVAL);
                        player.getInventory().clear();
                        player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 11), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                      }
                      else if (EventSystem.main.airBaseR.contains(player))
                      {
                        player.teleport(StartCommand.RedAirBase);
                        player.setGameMode(GameMode.SURVIVAL);
                        player.getInventory().clear();
                        player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.BOW, 1), new ItemStack(Material.STONE_PICKAXE, 1), new ItemStack(Material.GOLDEN_APPLE, 6), new ItemStack(Material.STONE, 128), new ItemStack(Material.WOOD, 64), new ItemStack(Material.WOOL, 192, (short) 14), new ItemStack(Material.STONE_BUTTON, 10), new ItemStack(Material.TORCH, 32), new ItemStack(Material.LADDER, 32), new ItemStack(Material.REDSTONE_LAMP_OFF, 10), new ItemStack(Material.ARROW, 192), new ItemStack(Material.BREAD, 64), new ItemStack(Material.IRON_HELMET, 1), new ItemStack(Material.IRON_CHESTPLATE, 1), new ItemStack(Material.IRON_LEGGINGS, 1), new ItemStack(Material.IRON_BOOTS, 1) });
                      }
                    }
                    else {
                      player.teleport(Bukkit.getServer().getWorld("world").getSpawnLocation());
                    }
                  }
                }, 20L);
              }
            }, 20L);
          }
        }, 20L);
      }
    }
  }
  
  @EventHandler
  public void JetMachineGunClick(PlayerInteractEvent e)
  {
    final Player player = e.getPlayer();
    if ((StartCommand.infilState == GameState.INGAME) && (main.gameMode.containsKey(player)) && 
      (((String)main.gameMode.get(player)).equals("Infiltration")) && 
      (main.airBase.contains(player)) && 
      (player.getWorld().getBlockAt(player.getLocation().getBlockX(), player.getLocation().getBlockY() - 1, player.getLocation().getBlockZ()).getType().equals(Material.SLIME_BLOCK)) && 
      (player.getWorld().getBlockAt(player.getLocation().getBlockX(), player.getLocation().getBlockY() - 2, player.getLocation().getBlockZ()).getType().equals(Material.CONCRETE)) && 
      ((e.getAction() == Action.RIGHT_CLICK_AIR) || (e.getAction() == Action.RIGHT_CLICK_BLOCK)) && 
      (!main.machineGunCooldown.contains(player)))
    {
      player.launchProjectile(Arrow.class);
      main.machineGunCooldown.add(player);
      
      Bukkit.getScheduler().runTaskLater(main, new Runnable()
      {
        public void run()
        {
          EventSystem.main.machineGunCooldown.remove(player);
        }
      }, 3L);
    }
  }
  
  @EventHandler
  public void JetCannonClick(PlayerInteractEvent e)
  {
    final Player player = e.getPlayer();
    if ((StartCommand.infilState == GameState.INGAME) && (main.gameMode.containsKey(player)) && 
      (((String)main.gameMode.get(player)).equals("Infiltration")) && 
      (main.airBase.contains(player)) && (player.getWorld().getBlockAt(player.getLocation().getBlockX(), player.getLocation().getBlockY() - 1, player.getLocation().getBlockZ()).getType().equals(Material.SLIME_BLOCK)) && 
      (player.getWorld().getBlockAt(player.getLocation().getBlockX(), player.getLocation().getBlockY() - 2, player.getLocation().getBlockZ()).getType().equals(Material.CONCRETE)) && 
      (e.getAction() == Action.LEFT_CLICK_AIR) && 
      (!main.cannonCooldown.contains(player)))
    {
      player.launchProjectile(Fireball.class);
      main.cannonCooldown.add(player);
      player.sendMessage("Fireball shot! Wait 5 seconds to shoot again.");
      
      Bukkit.getScheduler().runTaskLater(main, new Runnable()
      {
        public void run()
        {
          Main.rm.sendActionBar(player, "����2You can use ����eFireball����2 again in ����e5s");
          Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
          {
            public void run()
            {
              Main.rm.sendActionBar(player, "����2You can use ����eFireball����2 again in ����e4s");
              Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
              {
                public void run()
                {
                  Main.rm.sendActionBar(player, "����2You can use ����eFireball����2 again in ����e3s");
                  Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                  {
                    public void run()
                    {
                      Main.rm.sendActionBar(player, "����2You can use ����eFireball����2 again in ����e2s");
                      Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                      {
                        public void run()
                        {
                          Main.rm.sendActionBar(player, "����2You can use ����eFireball����2 again in ����e1s");
                          Bukkit.getScheduler().runTaskLater(EventSystem.main, new Runnable()
                          {
                            public void run()
                            {
                              Main.rm.sendActionBar(player, "����2You can use ����eFireball����2 again ����enow");
                              EventSystem.main.cannonCooldown.remove(player);
                            }
                          }, 20L);
                        }
                      }, 20L);
                    }
                  }, 20L);
                }
              }, 20L);
            }
          }, 20L);
        }
      }, 20L);
    }
  }
  
  @EventHandler
  public void noHunger(FoodLevelChangeEvent e)
  {
    if (e.getEntity().getWorld().equals(Bukkit.getWorld("world"))) {
      e.setCancelled(true);
    }
  }
  
  @EventHandler
  public void RespawnJet(PlayerInteractEvent e)
  {
    Player player = e.getPlayer();
    if ((main.airBase.contains(player)) && 
      (e.getAction() == Action.RIGHT_CLICK_BLOCK) && 
      (e.getClickedBlock().getType().equals(Material.STONE_BUTTON)))
    {
      World w = null;
      if (Bukkit.getServer().getWorld("Fire") == null) {
        w = Bukkit.getServer().getWorld("world");
      } else {
        w = Bukkit.getServer().getWorld("Fire");
      }
      if (e.getClickedBlock().getLocation().equals(new Location(w, -57.0D, 77.0D, 49.0D)))
      {
        if ((main.respawnBlueJetCooldown.containsKey(player)) && (((Long)main.respawnBlueJetCooldown.get(player)).longValue() > System.currentTimeMillis()))
        {
          long longRemaining = ((Long)main.respawnBlueJetCooldown.get(player)).longValue() - System.currentTimeMillis();
          int intRemaining = (int)(longRemaining / 1000L);
          player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
        }
        else
        {
          main.respawnBlueJetCooldown.put(player, Long.valueOf(System.currentTimeMillis() + 60000L));
          player.sendMessage("Jet Spawned!");
          WorldEditPlugin we = (WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit");
          File ABBJet2 = new File("plugins/WorldEdit/schematics/ABBJet2.schematic");
          EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(Bukkit.getServer().getWorld("Fire")), 1000000);
          try
          {
            MCEditSchematicFormat.getFormat(ABBJet2).load(ABBJet2).paste(session, new Vector(-55, 77, 65), false);
          }
          catch (MaxChangedBlocksException|DataException|IOException e2)
          {
            e2.printStackTrace();
          }
        }
      }
      else if (e.getClickedBlock().getLocation().equals(new Location(w, -67.0D, 77.0D, 49.0D)))
      {
        if ((main.respawnBlueJetCooldown2.containsKey(player)) && (((Long)main.respawnBlueJetCooldown2.get(player)).longValue() > System.currentTimeMillis()))
        {
          long longRemaining = ((Long)main.respawnBlueJetCooldown2.get(player)).longValue() - System.currentTimeMillis();
          int intRemaining = (int)(longRemaining / 1000L);
          player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
        }
        else
        {
          main.respawnBlueJetCooldown2.put(player, Long.valueOf(System.currentTimeMillis() + 60000L));
          player.sendMessage("Jet Spawned!");
          WorldEditPlugin we = (WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit");
          File ABBJet2 = new File("plugins/WorldEdit/schematics/ABBJet2.schematic");
          EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
          try
          {
            MCEditSchematicFormat.getFormat(ABBJet2).load(ABBJet2).paste(session, new Vector(-69, 77, 65), false);
          }
          catch (MaxChangedBlocksException|DataException|IOException e2)
          {
            e2.printStackTrace();
          }
        }
      }
      else if (e.getClickedBlock().getLocation().equals(new Location(w, -57.0D, 77.0D, -49.0D)))
      {
        if ((main.respawnRedJetCooldown.containsKey(player)) && (((Long)main.respawnRedJetCooldown.get(player)).longValue() > System.currentTimeMillis()))
        {
          long longRemaining = ((Long)main.respawnRedJetCooldown.get(player)).longValue() - System.currentTimeMillis();
          int intRemaining = (int)(longRemaining / 1000L);
          player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
        }
        else
        {
          main.respawnRedJetCooldown.put(player, Long.valueOf(System.currentTimeMillis() + 60000L));
          player.sendMessage("Jet Spawned!");
          WorldEditPlugin we = (WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit");
          File ABRJet2 = new File("plugins/WorldEdit/schematics/ABRJet2.schematic");
          EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
          try
          {
            MCEditSchematicFormat.getFormat(ABRJet2).load(ABRJet2).paste(session, new Vector(-55, 77, -65), false);
          }
          catch (MaxChangedBlocksException|DataException|IOException e2)
          {
            e2.printStackTrace();
          }
        }
      }
      else if (e.getClickedBlock().getLocation().equals(new Location(w, -67.0D, 77.0D, -49.0D))) {
        if ((main.respawnRedJetCooldown2.containsKey(player)) && (((Long)main.respawnRedJetCooldown2.get(player)).longValue() > System.currentTimeMillis()))
        {
          long longRemaining = ((Long)main.respawnRedJetCooldown2.get(player)).longValue() - System.currentTimeMillis();
          int intRemaining = (int)(longRemaining / 1000L);
          player.sendMessage("You must wait " + intRemaining + " seconds before you can respawn a jet!");
        }
        else
        {
          main.respawnRedJetCooldown2.put(player, Long.valueOf(System.currentTimeMillis() + 60000L));
          player.sendMessage("Jet Spawned!");
          WorldEditPlugin we = (WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit");
          File ABRJet2 = new File("plugins/WorldEdit/schematics/ABRJet2.schematic");
          EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
          try
          {
            MCEditSchematicFormat.getFormat(ABRJet2).load(ABRJet2).paste(session, new Vector(-69, 77, -65), false);
          }
          catch (MaxChangedBlocksException|DataException|IOException e2)
          {
            e2.printStackTrace();
          }
        }
      }
    }
  }
  
  @EventHandler
  public void TutorialReset(PlayerInteractEvent e)
  {
    Player player = e.getPlayer();
    if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) && 
      (e.getClickedBlock().getType().equals(Material.STONE_BUTTON)))
    {
      World w = null;
      if (Bukkit.getServer().getWorld("Fire") == null) {
        w = Bukkit.getServer().getWorld("world");
      } else {
        w = Bukkit.getServer().getWorld("Fire");
      }
      if (e.getClickedBlock().getLocation().equals(new Location(w, -1.5D, 84.0D, -1353.5D)))
      {
        WorldEditPlugin we = (WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit");
        File SFTutorial2 = new File("plugins/WorldEdit/schematics/SFTutorial2.schematic");
        EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(Bukkit.getServer().getWorld("Fire")), 1000000);
        try
        {
          MCEditSchematicFormat.getFormat(SFTutorial2).load(SFTutorial2).paste(session, new Vector(-2.0D, 86.0D, -1397.0D), true);
        }
        catch (MaxChangedBlocksException|DataException|IOException e2)
        {
          e2.printStackTrace();
        }
      }
    }
  }
}
