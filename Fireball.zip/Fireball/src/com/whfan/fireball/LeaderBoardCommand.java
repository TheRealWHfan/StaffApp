package com.whfan.fireball;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LeaderBoardCommand
  implements CommandExecutor
{
  private static Main main;
  public List<Integer> offlineList;
  public List<Integer> onlineList;
  List<Integer> allPlayerMoneyRaw = new ArrayList();
  public String richest;
  
  public LeaderBoardCommand(Main main)
  {
    main = main;
  }
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] arg3)
  {
    Player player = (Player)sender;
    
    player.sendMessage(main.money.keySet());
    
    return false;
  }
}
