package com.whfan.fireball;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.data.DataException;
import com.sk89q.worldedit.schematic.MCEditSchematicFormat;

public class ResetCommand implements CommandExecutor
{

  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player player = (Player)sender;
    
    player.sendMessage("reset");
    World w = null;
	if(Bukkit.getServer().getWorld("Fire") == null){
		w = Bukkit.getServer().getWorld("world");
	} else {
		w = Bukkit.getServer().getWorld("Fire");
	}
    WorldEditPlugin we = (WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit");
    File schematic = new File("plugins/WorldEdit/schematics/SFSchematic1.schematic");
    EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
    try {
      MCEditSchematicFormat.getFormat(schematic).load(schematic).paste(session, new Vector(0, 76, 0), false);
      return true;
    }
    catch (MaxChangedBlocksException|DataException|IOException e2)
    {
      e2.printStackTrace();
    }
    
    return false;
  }
}
