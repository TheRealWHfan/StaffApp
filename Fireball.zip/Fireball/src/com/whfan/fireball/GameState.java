package com.whfan.fireball;

public enum GameState {

	READY,INGAME,RESETTING;
	
}
