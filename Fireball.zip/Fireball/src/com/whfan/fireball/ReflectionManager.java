package com.whfan.fireball;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import net.minecraft.server.v1_12_R1.ChatMessageType;

public class ReflectionManager {
	
	public void sendActionBar(Player p, String message){
        Constructor<?> actionBarConstructor;
		try {
			actionBarConstructor = getNMSClass("PacketPlayOutChat").getConstructor(getNMSClass("IChatBaseComponent"), ChatMessageType.class);
			Object chat = getNMSClass("IChatBaseComponent").getDeclaredClasses()[0].getMethod("a", String.class).invoke(null, "{\"text\": \"" + message +"\"}");
	        Object packet = actionBarConstructor.newInstance(chat, ChatMessageType.GAME_INFO);
	        sendPacket(p, packet);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		}
        
	}
	
	public void sendParticlePacket(Player p, String effect, boolean t, float x, float y, float z, float dx, float dy, float dz, float speed, int count){
		try {
		Constructor<?> particleConstructor = getNMSClass("PacketPlayOutWorldParticles").getConstructor(getNMSClass("EnumParticle"), boolean.class, float.class, float.class, float.class, float.class, float.class, float.class, float.class, int.class, int[].class);
		@SuppressWarnings({"rawtypes", "unchecked" })
		Object en =  Enum.valueOf((Class<? extends Enum>) getNMSClass("EnumParticle"), effect);
		Object packet = particleConstructor.newInstance(en, t, x, y, z, dx, dy, dz, speed, count, null);
		sendPacket(p, packet);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		}
	}
	
	public void sendPacket(Player p, Object packet){
		try {
		Object nmsPlayer = p.getClass().getMethod("getHandle").invoke(p);
		Object playerConnection = nmsPlayer.getClass().getField("playerConnection").get(nmsPlayer);
		playerConnection.getClass().getMethod("sendPacket", getNMSClass("Packet")).invoke(playerConnection, packet);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}
	}
	
	
	public Class<?> getNMSClass(String name){
		try {
		String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
		return Class.forName("net.minecraft.server." + version + "." + name);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public Class<?> getCBClass(String name){
		try {
		String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
		return Class.forName("org.bukkit.craftbukkit." + version + "." + name);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		return null;
	}
	
}
