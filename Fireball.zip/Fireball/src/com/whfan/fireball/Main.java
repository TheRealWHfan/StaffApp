package com.whfan.fireball;

import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

public class Main
  extends JavaPlugin
{
  public static ReflectionManager rm = new ReflectionManager();
  private File dataBase;
  private YamlConfiguration modifyDataBase;
  
  public static WorldEditPlugin getAPI()
  {
    Plugin plugin = Bukkit.getServer().getPluginManager().getPlugin("WorldEdit");
    if ((plugin instanceof WorldEditPlugin)) {
      return (WorldEditPlugin)plugin;
    }
    return null;
  }
  
  public HashMap<UUID, String> money = new HashMap();
  public ArrayList<Player> stoneFortress = new ArrayList();
  public ArrayList<Player> stoneFortressB = new ArrayList();
  public ArrayList<Player> stoneFortressR = new ArrayList();
  public ArrayList<Player> stoneFortressBDead = new ArrayList();
  public ArrayList<Player> stoneFortressRDead = new ArrayList();
  public ArrayList<Player> airBase = new ArrayList();
  public ArrayList<Player> airBaseB = new ArrayList();
  public ArrayList<Player> airBaseR = new ArrayList();
  public ArrayList<Player> airBaseBDead = new ArrayList();
  public ArrayList<Player> airBaseRDead = new ArrayList();
  public ArrayList<Player> skyIsland = new ArrayList();
  public ArrayList<Player> skyIslandB = new ArrayList();
  public ArrayList<Player> skyIslandR = new ArrayList();
  public ArrayList<Player> skyIslandBDead = new ArrayList();
  public ArrayList<Player> skyIslandRDead = new ArrayList();
  public ArrayList<Player> immuneToFire = new ArrayList();
  public ArrayList<Player> machineGunCooldown = new ArrayList();
  public ArrayList<Player> cannonCooldown = new ArrayList();
  public ArrayList<Player> offlineLeavePlayer = new ArrayList();
  public HashMap<Player, String> gameMode = new HashMap();
  public HashMap<Player, Long> respawnBlueJetCooldown = new HashMap();
  public HashMap<Player, Long> respawnBlueJetCooldown2 = new HashMap();
  public HashMap<Player, Long> respawnRedJetCooldown = new HashMap();
  public HashMap<Player, Long> respawnRedJetCooldown2 = new HashMap();
  public static ArrayList<Player> Messaged = new ArrayList();
  public static ArrayList<FallingBlock> fire = new ArrayList();
  
  public void onEnable()
  {
    System.out.println("Fireball v1.0 enabled!");
    
    getCommand("gamestart").setExecutor(new StartCommand(this));
    getCommand("gameend").setExecutor(new EndCommand(this));
    getCommand("gamereset").setExecutor(new ResetCommand());
    getCommand("gameshop").setExecutor(new ShopCommand(this));
    getCommand("gameleave").setExecutor(new LeaveCommand(this));
    getCommand("gamedebug").setExecutor(new DebugCommand());
    getCommand("spawnleaderboard").setExecutor(new SLeaderBoardCommand());
    getCommand("leaderboard").setExecutor(new LeaderBoardCommand(this));
    getCommand("money").setExecutor(new MoneyCommand(this));
    Bukkit.getPluginManager().registerEvents(new EventSystem(this), this);
    Bukkit.getPluginManager().registerEvents(new CustomItems(this), this);
    Bukkit.getPluginManager().registerEvents(new CustomMobs(this), this);
    try
    {
      initiateFiles();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    if (getAPI() != null)
    {
      System.out.println("WorldEdit has been hooked to Fireball v1.0");
    }
    else
    {
      System.out.println("WorldEdit doesnt exist! Install worldedit to enable Fireball v1.0!");
      Bukkit.getPluginManager().disablePlugin(this);
    }
    getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
    {
      public void run()
      {
        if (StartCommand.mode.equals("Infiltration")) {
          EventSystem.InfiltrationWin();
        }
      }
    }, 0L, 5L);
    
    getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
    {
      public void run()
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if ((Main.this.airBase.contains(aop)) && (StartCommand.infilState == GameState.INGAME) && 
            (aop.getWorld().getBlockAt(aop.getLocation().getBlockX(), aop.getLocation().getBlockY() - 1, aop.getLocation().getBlockZ()).getType().equals(Material.SLIME_BLOCK)) && 
            (aop.getWorld().getBlockAt(aop.getLocation().getBlockX(), aop.getLocation().getBlockY() - 2, aop.getLocation().getBlockZ()).getType().equals(Material.CONCRETE)) && 
            (!Main.Messaged.contains(aop)))
          {
            aop.sendMessage("Jet: Left Click - Missile : Right Click - Machine Gun");
            Main.Messaged.add(aop);
          }
        }
      }
    }, 0L, 5L);
    
    getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
    {
      public void run()
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if ((Main.this.airBase.contains(aop)) && 
            (StartCommand.infilState == GameState.INGAME) && 
            (aop.getWorld().equals(Bukkit.getWorld("Fire"))))
          {
            if (Bukkit.getWorld("Fire").getBlockAt(-62, 84, 34).getType().equals(Material.AIR)) {
              EventSystem.InfiltrationWin();
            }
            if (Bukkit.getWorld("Fire").getBlockAt(-62, 84, -34).getType().equals(Material.AIR)) {
              EventSystem.InfiltrationWin();
            }
          }
        }
      }
    }, 0L, 10L);
    
    getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
    {
      public void run()
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if ((Main.this.gameMode.containsKey(aop)) && 
            (((String)Main.this.gameMode.get(aop)).equals("Classic")))
          {
            Random rand = new Random();
            int rng = rand.nextInt(3);
            switch (rng)
            {
            case 1: 
              aop.sendMessage(ChatColor.RED + "Tips: " + ChatColor.WHITE + "Use the slimeblock machine located at the back of your base to get over to the enemy base.");
              break;
            case 2: 
              aop.sendMessage(ChatColor.RED + "Tips: " + ChatColor.WHITE + "Eggs explode!");
            case 3: 
              aop.sendMessage(ChatColor.RED + "Tips: " + ChatColor.WHITE + "The buttons located above a lantern and are on the floor are fireball turrets. Right click them to spawn fireballs.");
            }
          }
        }
      }
    }, 0L, 3600L);
    
    getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
    {
      public void run()
      {
        for (Player aop : Bukkit.getOnlinePlayers()) {
          if (Main.this.gameMode.containsKey(aop))
          {
            if ((((String)Main.this.gameMode.get(aop)).equals("Classic")) && (StartCommand.state == GameState.INGAME) && (aop.getWorld().equals(Bukkit.getWorld("Fire"))))
            {
              ItemStack explosiveEgg = new ItemStack(Material.EGG, 6);
              ItemMeta explosiveEggMeta = explosiveEgg.getItemMeta();
              explosiveEggMeta.setDisplayName(ChatColor.YELLOW + "Explosive Egg");
              explosiveEgg.setItemMeta(explosiveEggMeta);
              
              ItemStack flameThrower = new ItemStack(Material.BLAZE_ROD, 1);
              ItemMeta flameThrowerMeta = flameThrower.getItemMeta();
              flameThrowerMeta.setDisplayName(ChatColor.RED + "Flamethrower");
              flameThrowerMeta.addEnchant(Enchantment.FIRE_ASPECT, 1, true);
              flameThrower.setItemMeta(flameThrowerMeta);
              
              Random rand = new Random();
              int rng = rand.nextInt(8);
              switch (rng)
              {
              case 1: 
                if (Main.this.stoneFortressB.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 2: 
                if (Main.this.stoneFortressR.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 3: 
                if ((Main.this.stoneFortressB.contains(aop)) && 
                  (!aop.getInventory().contains(flameThrower)))
                {
                  aop.getInventory().addItem(new ItemStack[] { flameThrower });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved a flamethrower!");
                }
                break;
              case 4: 
                if ((Main.this.stoneFortressR.contains(aop)) && 
                  (!aop.getInventory().contains(flameThrower)))
                {
                  aop.getInventory().addItem(new ItemStack[] { flameThrower });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved a flamethrower!");
                }
                break;
              case 5: 
                if (Main.this.stoneFortressB.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 6: 
                if (Main.this.stoneFortressR.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 7: 
                if (Main.this.stoneFortressB.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 8: 
                if (Main.this.stoneFortressR.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              }
            }
            if ((((String)Main.this.gameMode.get(aop)).equals("Infiltration")) && (StartCommand.infilState.equals(GameState.INGAME)) && (aop.getWorld().equals(Bukkit.getWorld("Fire"))))
            {
              Random rand = new Random();
              int rng = rand.nextInt(8);
              
              ItemStack explosiveEgg = new ItemStack(Material.EGG, 6);
              ItemMeta explosiveEggMeta = explosiveEgg.getItemMeta();
              explosiveEggMeta.setDisplayName(ChatColor.YELLOW + "Explosive Egg");
              explosiveEgg.setItemMeta(explosiveEggMeta);
              
              ItemStack flameThrower = new ItemStack(Material.BLAZE_ROD, 1);
              ItemMeta flameThrowerMeta = flameThrower.getItemMeta();
              flameThrowerMeta.setDisplayName(ChatColor.RED + "Flamethrower");
              flameThrowerMeta.addEnchant(Enchantment.FIRE_ASPECT, 1, true);
              flameThrower.setItemMeta(flameThrowerMeta);
              switch (rng)
              {
              case 1: 
                if (Main.this.airBaseB.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 2: 
                if (Main.this.airBaseR.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 3: 
                if ((Main.this.airBaseB.contains(aop)) && 
                  (!aop.getInventory().contains(flameThrower)))
                {
                  aop.getInventory().addItem(new ItemStack[] { flameThrower });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved a flamethrower!");
                }
                break;
              case 4: 
                if ((Main.this.airBaseR.contains(aop)) && 
                  (!aop.getInventory().contains(flameThrower)))
                {
                  aop.getInventory().addItem(new ItemStack[] { flameThrower });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved a flamethrower!");
                }
                break;
              case 5: 
                if (Main.this.airBaseB.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 6: 
                if (Main.this.airBaseR.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 7: 
                if (Main.this.airBaseB.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              case 8: 
                if (Main.this.airBaseR.contains(aop))
                {
                  aop.getInventory().addItem(new ItemStack[] { explosiveEgg });
                  aop.sendMessage(ChatColor.GRAY + "You have recieved 6 explosive eggs!");
                }
                break;
              }
            }
          }
        }
      }
    }, 0L, 400L);
    
    getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
    {
      public void run()
      {
        for (Entity entity : Bukkit.getWorld("Fire").getEntities())
        {
          if ((entity instanceof Fireball)) {
            entity.getWorld().spawnParticle(Particle.REDSTONE, entity.getLocation(), 3);
          }
          if ((entity instanceof Egg)) {
            entity.getWorld().spawnParticle(Particle.HEART, entity.getLocation(), 3);
          }
        }
      }
    }, 0L, 1L);
    
    getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
    {
      public void run()
      {
        Iterator localIterator2;
        label194:
        for (Iterator localIterator1 = Bukkit.getWorld("Fire").getEntities().iterator(); localIterator1.hasNext(); localIterator2.hasNext())
        {
          Entity entity = (Entity)localIterator1.next();
          if ((!(entity instanceof FallingBlock)) || 
            (!((FallingBlock)entity).getMaterial().equals(Material.FIRE))) {
            break label194;
          }
          localIterator2 = (Iterator) entity.getNearbyEntities(1.0D, 1.0D, 1.0D);
          Entity eir = (Entity)localIterator2.next();
          eir.setFireTicks(60);
          if ((eir instanceof Player))
          {
            Player pir = (Player) eir;
            if (fire.contains(entity)) {
            	pir.damage(2.0);
            }
          }
        }
      }
    }, 0L, 30L);
    for (Player aop : Bukkit.getOnlinePlayers()) {
      if (getDataBase().contains(aop.getUniqueId().toString()))
      {
        this.money.put(aop.getUniqueId(), getDataBase().getString(aop.getUniqueId().toString() + ".Money"));
        getDataBase().set(aop.getUniqueId().toString() + ".IGN", aop.getName());
      }
      else
      {
        getDataBase().createSection(aop.getUniqueId().toString());
        getDataBase().set(aop.getUniqueId().toString() + ".IGN", aop.getName());
        getDataBase().set(aop.getUniqueId().toString() + ".Money", "0");
        this.money.put(aop.getUniqueId(), "0");
      }
    }
  }
  
  public YamlConfiguration getDataBase()
  {
    return this.modifyDataBase;
  }
  
  public File getFile()
  {
    return this.dataBase;
  }
  
  public void initiateFiles()
    throws IOException
  {
    this.dataBase = new File(Bukkit.getServer().getPluginManager().getPlugin("Fireball").getDataFolder(), "Database.yml");
    if (!this.dataBase.exists()) {
      this.dataBase.createNewFile();
    }
    this.modifyDataBase = YamlConfiguration.loadConfiguration(this.dataBase);
  }
  
  public void onDisable()
  {
    System.out.println("Fireball v1.0 disabled!");
    for (Player aop : Bukkit.getOnlinePlayers()) {
      if (this.money.containsKey(aop.getUniqueId())) {
        getDataBase().set(aop.getUniqueId().toString() + ".Money", this.money.get(aop.getUniqueId()));
      } else {
        getDataBase().set(aop.getUniqueId().toString() + ".Money", "0");
      }
    }
    try
    {
      getDataBase().save(getFile());
    }
    catch (IOException e1)
    {
      e1.printStackTrace();
    }
  }
}
