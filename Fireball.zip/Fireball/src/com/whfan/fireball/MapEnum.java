package com.whfan.fireball;

public class MapEnum {

	public static final String StoneFortress = "SF", AirBase = "AB", NoMap = "NoMap";
	
}
