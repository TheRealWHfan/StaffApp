package com.whfan.fireball;

public class ModeEnum {
	
	public static final String Classic = "Classic", Infiltration = "Infiltration", NoMode = "NoMode";

}
