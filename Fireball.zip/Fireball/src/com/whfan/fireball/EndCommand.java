package com.whfan.fireball;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.schematic.MCEditSchematicFormat;

public class EndCommand implements CommandExecutor {
	
	private Main main;

    public EndCommand(Main main) {
		
		this.main = main;
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		Player player = (Player) sender;
		
		StartCommand.state = GameState.RESETTING;
		//Send out the win message
		for(Player rTeamPlayer: StartCommand.Red){
			rTeamPlayer.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
			rTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
		}
		for(Player blueTeamPlayer: StartCommand.Blue){
			blueTeamPlayer.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Red", ChatColor.WHITE + "has just won the game!", 20, 60, 20);
			blueTeamPlayer.teleport(Bukkit.getWorld("world").getSpawnLocation());
		}

		//Set the mode back to default
		StartCommand.mode = ModeEnum.NoMode;
		//Reset the team size
		StartCommand.teamSize = "0";
		//Reset Map
		StartCommand.map = MapEnum.NoMap;
		//Clear Teams
		StartCommand.Blue.clear();
		StartCommand.Red.clear();
		//Setup The reset Task
		Bukkit.getScheduler().runTaskLater(main, new Runnable() {
			public void run() {
				if (StartCommand.map == MapEnum.AirBase) {
					World w = null;
					if(Bukkit.getServer().getWorld("Fire") == null){
						w = Bukkit.getServer().getWorld("world");
					} else {
						w = Bukkit.getServer().getWorld("Fire");
					}
					ArenaManager.pasteArena("ABSchematic1", "ABSchematic2", w, new Vector(-62,76,0), main);
				}
			}
		}, 20L);
		
		
		return false;
	}

}
