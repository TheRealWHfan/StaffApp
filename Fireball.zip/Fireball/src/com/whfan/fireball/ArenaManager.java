package com.whfan.fireball;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.bukkit.BukkitWorld;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.schematic.MCEditSchematicFormat;

public class ArenaManager {


	public static void pasteArena(String schematic1, String schematic2, World w, Vector location, Main main){
		Bukkit.broadcastMessage("Resetting Arena");
		WorldEditPlugin we = Main.getAPI();
		File SFSchematic1 = new File("plugins/WorldEdit/schematics/" + schematic1 + ".schematic");
		File SFSchematic2 = new File("plugins/WorldEdit/schematics/" + schematic2 + ".schematic");
		EditSession session = we.getWorldEdit().getEditSessionFactory().getEditSession(new BukkitWorld(w), 1000000);
		try {
			MCEditSchematicFormat.getFormat(SFSchematic1).load(SFSchematic1).paste(session, location, false);
			Bukkit.broadcastMessage("Schematic1 pasted");
		} catch (MaxChangedBlocksException | com.sk89q.worldedit.data.DataException | IOException e2) {
			e2.printStackTrace();
			Bukkit.broadcastMessage("Schematic error");
		}
		Bukkit.getScheduler().runTaskLater((Plugin) main, new Runnable() {
			public void run() {
				try {
					MCEditSchematicFormat.getFormat(SFSchematic2).load(SFSchematic2).paste(session, location, false);
					Bukkit.broadcastMessage("Schematic2 pasted");
				} catch (MaxChangedBlocksException
						| com.sk89q.worldedit.data.DataException | IOException e2) {
					e2.printStackTrace();
					Bukkit.broadcastMessage("Schematic error");
				}
			}
		}, 60L);
}

}
