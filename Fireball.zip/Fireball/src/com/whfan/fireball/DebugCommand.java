package com.whfan.fireball;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DebugCommand implements org.bukkit.command.CommandExecutor
{
  public DebugCommand() {}
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player player = (Player)sender;
    
    if (player.getName().equals("WHfan") || player.isOp()) {
      player.sendMessage("Debug:\nGame: " + StartCommand.teamSize + "\nMode: " + StartCommand.mode + "\nMap: " + StartCommand.map);
    } else {
      player.sendMessage("Only WHfan can perform this great command!");
    }
    
    return false;
  }
}
