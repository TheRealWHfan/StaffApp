package com.whfan.fireball;

import org.bukkit.event.Listener;

public class CustomMobs
  implements Listener
{
  private static Main main;
  
  public CustomMobs(Main main)
  {
    main = main;
  }
}
